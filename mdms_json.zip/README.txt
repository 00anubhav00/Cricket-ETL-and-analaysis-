This zip archive contains data files from Cricsheet in JSON format. This
archive contains 1960 MDM matches. A further 6 matches have been withheld due
to either featuring the Afghanistan men's team or being played in the
Afghanistan Premier League, due to the Cricsheet policy to no longer feature
matches involving Afghanistan men or played in Afghanistan Premier League (see
https://cricsheet.org/withheld-matches for more information).


The JSON data files contained in this zip file are version 1.0.0, and 1.1.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/mdms_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2025-07-29 - club - CCH - male - 1461937 - Leicestershire vs Kent
2025-07-29 - club - CCH - male - 1461936 - Glamorgan vs Lancashire
2025-07-29 - club - CCH - male - 1461935 - Middlesex vs Gloucestershire
2025-07-29 - club - CCH - male - 1461934 - Derbyshire vs Northamptonshire
2025-07-29 - club - CCH - male - 1461878 - Somerset vs Nottinghamshire
2025-07-29 - club - CCH - male - 1461877 - Hampshire vs Worcestershire
2025-07-29 - club - CCH - male - 1461876 - Sussex vs Yorkshire
2025-07-29 - club - CCH - male - 1461875 - Essex vs Warwickshire
2025-07-29 - club - CCH - male - 1461874 - Durham vs Surrey
2025-07-22 - club - CCH - male - 1461933 - Lancashire vs Gloucestershire
2025-07-22 - club - CCH - male - 1461932 - Leicestershire vs Derbyshire
2025-07-22 - club - CCH - male - 1461931 - Middlesex vs Northamptonshire
2025-07-22 - club - CCH - male - 1461930 - Kent vs Glamorgan
2025-07-22 - club - CCH - male - 1461873 - Worcestershire vs Warwickshire
2025-07-22 - club - CCH - male - 1461872 - Yorkshire vs Surrey
2025-07-22 - club - CCH - male - 1461871 - Sussex vs Essex
2025-07-22 - club - CCH - male - 1461870 - Nottinghamshire vs Hampshire
2025-07-22 - club - CCH - male - 1461869 - Durham vs Somerset
2025-06-29 - club - CCH - male - 1461929 - Gloucestershire vs Glamorgan
2025-06-29 - club - CCH - male - 1461928 - Lancashire vs Derbyshire
2025-06-29 - club - CCH - male - 1461927 - Kent vs Northamptonshire
2025-06-29 - club - CCH - male - 1461926 - Middlesex vs Leicestershire
2025-06-29 - club - CCH - male - 1461868 - Warwickshire vs Sussex
2025-06-29 - club - CCH - male - 1461867 - Worcestershire vs Hampshire
2025-06-29 - club - CCH - male - 1461866 - Somerset vs Nottinghamshire
2025-06-29 - club - CCH - male - 1461865 - Surrey vs Durham
2025-06-29 - club - CCH - male - 1461864 - Essex vs Yorkshire
2025-06-22 - club - CCH - male - 1461925 - Kent vs Lancashire
2025-06-22 - club - CCH - male - 1461924 - Gloucestershire vs Derbyshire
2025-06-22 - club - CCH - male - 1461923 - Glamorgan vs Leicestershire
2025-06-22 - club - CCH - male - 1461922 - Middlesex vs Northamptonshire
2025-06-22 - club - CCH - male - 1461863 - Nottinghamshire vs Yorkshire
2025-06-22 - club - CCH - male - 1461862 - Worcestershire vs Surrey
2025-06-22 - club - CCH - male - 1461861 - Somerset vs Warwickshire
2025-06-22 - club - CCH - male - 1461860 - Essex vs Hampshire
2025-06-22 - club - CCH - male - 1461859 - Sussex vs Durham
2025-05-23 - club - CCH - male - 1461921 - Derbyshire vs Kent
2025-05-23 - club - CCH - male - 1461920 - Northamptonshire vs Gloucestershire
2025-05-23 - club - CCH - male - 1461919 - Lancashire vs Leicestershire
2025-05-23 - club - CCH - male - 1461918 - Glamorgan vs Middlesex
2025-05-23 - club - CCH - male - 1461858 - Nottinghamshire vs Yorkshire
2025-05-23 - club - CCH - male - 1461857 - Warwickshire vs Worcestershire
2025-05-23 - club - CCH - male - 1461856 - Essex vs Surrey
2025-05-23 - club - CCH - male - 1461855 - Hampshire vs Sussex
2025-05-23 - club - CCH - male - 1461854 - Durham vs Somerset
2025-05-16 - club - CCH - male - 1461917 - Northamptonshire vs Glamorgan
2025-05-16 - club - CCH - male - 1461916 - Middlesex vs Leicestershire
2025-05-16 - club - CCH - male - 1461915 - Lancashire vs Derbyshire
2025-05-16 - club - CCH - male - 1461914 - Kent vs Gloucestershire
2025-05-16 - club - CCH - male - 1461853 - Worcestershire vs Essex
2025-05-16 - club - CCH - male - 1461852 - Hampshire vs Warwickshire
2025-05-16 - club - CCH - male - 1461851 - Yorkshire vs Surrey
2025-05-16 - club - CCH - male - 1461850 - Somerset vs Sussex
2025-05-16 - club - CCH - male - 1461849 - Nottinghamshire vs Durham
2025-05-09 - club - CCH - male - 1461913 - Glamorgan vs Kent
2025-05-09 - club - CCH - male - 1461912 - Northamptonshire vs Lancashire
2025-05-09 - club - CCH - male - 1461848 - Sussex vs Worcestershire
2025-05-09 - club - CCH - male - 1461847 - Nottinghamshire vs Hampshire
2025-05-09 - club - CCH - male - 1461846 - Warwickshire vs Surrey
2025-05-09 - club - CCH - male - 1461845 - Yorkshire vs Essex
2025-05-02 - club - CCH - male - 1461911 - Glamorgan vs Derbyshire
2025-05-02 - club - CCH - male - 1461910 - Lancashire vs Gloucestershire
2025-05-02 - club - CCH - male - 1461909 - Kent vs Middlesex
2025-05-02 - club - CCH - male - 1461908 - Leicestershire vs Northamptonshire
2025-05-02 - club - CCH - male - 1461844 - Essex vs Somerset
2025-05-02 - club - CCH - male - 1461843 - Durham vs Hampshire
2025-05-02 - club - CCH - male - 1461842 - Yorkshire vs Warwickshire
2025-04-25 - club - CCH - male - 1461907 - Derbyshire vs Middlesex
2025-04-25 - club - CCH - male - 1461906 - Gloucestershire vs Leicestershire
2025-04-25 - club - CCH - male - 1461841 - Worcestershire vs Durham
2025-04-25 - club - CCH - male - 1461840 - Somerset vs Surrey
2025-04-25 - club - CCH - male - 1461839 - Sussex vs Nottinghamshire
2025-04-18 - club - CCH - male - 1461905 - Derbyshire vs Northamptonshire
2025-04-18 - club - CCH - male - 1461904 - Gloucestershire vs Kent
2025-04-18 - club - CCH - male - 1461903 - Glamorgan vs Middlesex
2025-04-18 - club - CCH - male - 1461902 - Lancashire vs Leicestershire
2025-04-18 - club - CCH - male - 1461838 - Warwickshire vs Nottinghamshire
2025-04-18 - club - CCH - male - 1461837 - Somerset vs Hampshire
2025-04-18 - club - CCH - male - 1461836 - Essex vs Worcestershire
2025-04-18 - club - CCH - male - 1461835 - Yorkshire vs Durham
2025-04-18 - club - CCH - male - 1461834 - Sussex vs Surrey
2025-04-11 - club - CCH - male - 1461901 - Gloucestershire vs Glamorgan
2025-04-11 - club - CCH - male - 1461900 - Leicestershire vs Derbyshire
2025-04-11 - club - CCH - male - 1461899 - Northamptonshire vs Lancashire
2025-04-11 - club - CCH - male - 1461898 - Middlesex vs Kent
2025-04-11 - club - CCH - male - 1461833 - Yorkshire vs Worcestershire
2025-04-11 - club - CCH - male - 1461832 - Sussex vs Somerset
2025-04-11 - club - CCH - male - 1461831 - Surrey vs Hampshire
2025-04-11 - club - CCH - male - 1461830 - Nottinghamshire vs Essex
2025-04-11 - club - CCH - male - 1461829 - Durham vs Warwickshire
2025-04-04 - club - CCH - male - 1461897 - Glamorgan vs Leicestershire
2025-04-04 - club - CCH - male - 1461896 - Middlesex vs Lancashire
2025-04-04 - club - CCH - male - 1461895 - Gloucestershire vs Derbyshire
2025-04-04 - club - CCH - male - 1461894 - Kent vs Northamptonshire
2025-04-04 - club - CCH - male - 1461828 - Durham vs Nottinghamshire
2025-04-04 - club - CCH - male - 1461827 - Sussex vs Warwickshire
2025-04-04 - club - CCH - male - 1461826 - Worcestershire vs Somerset
2025-04-04 - club - CCH - male - 1461825 - Yorkshire vs Hampshire
2025-04-04 - club - CCH - male - 1461824 - Essex vs Surrey
2025-03-29 - club - PKS - male - 1452160 - Northern Districts vs Otago Volts
2025-03-29 - club - PKS - male - 1452159 - Wellington Firebirds vs Canterbury
2025-03-29 - club - PKS - male - 1452158 - Auckland Aces vs Central Stags
2025-03-26 - club - SSH - male - 1444522 - Queensland vs South Australia
2025-03-21 - club - PKS - male - 1452157 - Otago Volts vs Auckland Aces
2025-03-21 - club - PKS - male - 1452156 - Central Stags vs Canterbury
2025-03-21 - club - PKS - male - 1452155 - Northern Districts vs Wellington Firebirds
2025-03-15 - club - SSH - male - 1444521 - Victoria vs Western Australia
2025-03-15 - club - SSH - male - 1444520 - South Australia vs Queensland
2025-03-15 - club - SSH - male - 1444519 - Tasmania vs New South Wales
2025-03-13 - club - PKS - male - 1452154 - Otago Volts vs Central Stags
2025-03-13 - club - PKS - male - 1452153 - Wellington Firebirds vs Canterbury
2025-03-13 - club - PKS - male - 1452152 - Auckland Aces vs Northern Districts
2025-03-06 - club - SSH - male - 1444518 - Western Australia vs New South Wales
2025-03-06 - club - SSH - male - 1444517 - Queensland vs Tasmania
2025-03-06 - club - SSH - male - 1444516 - Victoria vs South Australia
2025-03-05 - club - PKS - male - 1452151 - Wellington Firebirds vs Otago Volts
2025-03-05 - club - PKS - male - 1452150 - Northern Districts vs Canterbury
2025-03-05 - club - PKS - male - 1452149 - Central Stags vs Auckland Aces
2025-03-05 - club - MLT - male - 1465865 - Bloomfield Cricket and Athletic Club vs Nondescripts Cricket Club
2025-02-28 - club - MLT - male - 1465860 - Negombo Cricket Club vs Ragama Cricket Club
2025-02-28 - club - MLT - male - 1465859 - Badureliya Sports Club vs Bloomfield Cricket and Athletic Club
2025-02-28 - club - MLT - male - 1465858 - Chilaw Marians Cricket Club vs Colts Cricket Club
2025-02-28 - club - MLT - male - 1465857 - Panadura Sports Club vs Ace Capital Cricket Club
2025-02-23 - club - MLT - male - 1465852 - Negombo Cricket Club vs Badureliya Sports Club
2025-02-21 - club - MLT - male - 1465864 - Colombo Cricket Club vs Burgher Recreation Club
2025-02-21 - club - MLT - male - 1465863 - Kandy Customs Cricket Club vs Moors Sports Club
2025-02-21 - club - MLT - male - 1465862 - Nugegoda Sports Welfare Club vs Tamil Union Cricket and Athletic Club
2025-02-18 - club - SSH - male - 1444515 - South Australia vs Tasmania
2025-02-18 - club - SSH - male - 1444514 - Queensland vs Western Australia
2025-02-18 - club - SSH - male - 1444513 - New South Wales vs Victoria
2025-02-14 - club - MLT - male - 1465856 - Kandy Customs Cricket Club vs Colombo Cricket Club
2025-02-14 - club - MLT - male - 1465855 - Nugegoda Sports Welfare Club vs Burgher Recreation Club
2025-02-14 - club - MLT - male - 1465854 - Kurunegala Youth Cricket Club vs Moors Sports Club
2025-02-14 - club - MLT - male - 1465853 - Nondescripts Cricket Club vs Sinhalese Sports Club
2025-02-14 - club - MLT - male - 1465851 - Bloomfield Cricket and Athletic Club vs Panadura Sports Club
2025-02-14 - club - MLT - male - 1465850 - Ace Capital Cricket Club vs Police Sports Club
2025-02-13 - club - MLT - male - 1465849 - Chilaw Marians Cricket Club vs Ragama Cricket Club
2025-02-08 - club - SSH - male - 1444512 - Western Australia vs South Australia
2025-02-08 - club - SSH - male - 1444511 - Queensland vs New South Wales
2025-02-08 - club - SSH - male - 1444510 - Tasmania vs Victoria
2025-02-07 - club - MLT - male - 1465848 - Nugegoda Sports Welfare Club vs Kandy Customs Cricket Club
2025-02-07 - club - MLT - male - 1465847 - Colombo Cricket Club vs Kurunegala Youth Cricket Club
2025-02-07 - club - MLT - male - 1465846 - Moors Sports Club vs Nondescripts Cricket Club
2025-02-07 - club - MLT - male - 1465845 - Chilaw Marians Cricket Club vs Badureliya Sports Club
2025-02-07 - club - MLT - male - 1465844 - Negombo Cricket Club vs Panadura Sports Club
2025-02-07 - club - MLT - male - 1465843 - Bloomfield Cricket and Athletic Club vs Ace Capital Cricket Club
2025-02-07 - club - MLT - male - 1465841 - Tamil Union Cricket and Athletic Club vs Sinhalese Sports Club
2025-01-31 - club - MLT - male - 1465840 - Kurunegala Youth Cricket Club vs Nugegoda Sports Welfare Club
2025-01-31 - club - MLT - male - 1465839 - Colombo Cricket Club vs Nondescripts Cricket Club
2025-01-31 - club - MLT - male - 1465838 - Tamil Union Cricket and Athletic Club vs Burgher Recreation Club
2025-01-31 - club - MLT - male - 1465836 - Chilaw Marians Cricket Club vs Panadura Sports Club
2025-01-31 - club - MLT - male - 1465835 - Ace Capital Cricket Club vs Negombo Cricket Club
2025-01-31 - club - MLT - male - 1465834 - Colts Cricket Club vs Ragama Cricket Club
2025-01-30 - club - MLT - male - 1465833 - Bloomfield Cricket and Athletic Club vs Police Sports Club
2025-01-26 - club - MLT - male - 1465828 - Ace Capital Cricket Club vs Chilaw Marians Cricket Club
2025-01-25 - club - MLT - male - 1465831 - Kandy Customs Cricket Club vs Tamil Union Cricket and Athletic Club
2025-01-24 - club - MLT - male - 1465832 - Nugegoda Sports Welfare Club vs Nondescripts Cricket Club
2025-01-24 - club - MLT - male - 1465830 - Colombo Cricket Club vs Moors Sports Club
2025-01-24 - club - MLT - male - 1465829 - Sinhalese Sports Club vs Burgher Recreation Club
2025-01-24 - club - MLT - male - 1465827 - Badureliya Sports Club vs Colts Cricket Club
2025-01-24 - club - MLT - male - 1465826 - Bloomfield Cricket and Athletic Club vs Negombo Cricket Club
2025-01-24 - club - MLT - male - 1465825 - Police Sports Club vs Ragama Cricket Club
2025-01-19 - club - MLT - male - 1465819 - Chilaw Marians Cricket Club vs Bloomfield Cricket and Athletic Club
2025-01-18 - club - MLT - male - 1465823 - Moors Sports Club vs Nugegoda Sports Welfare Club
2025-01-17 - club - MLT - male - 1465824 - Kurunegala Youth Cricket Club vs Tamil Union Cricket and Athletic Club
2025-01-17 - club - MLT - male - 1465822 - Kandy Customs Cricket Club vs Burgher Recreation Club
2025-01-17 - club - MLT - male - 1465820 - Colts Cricket Club vs Panadura Sports Club
2025-01-17 - club - MLT - male - 1465818 - Ragama Cricket Club vs Badureliya Sports Club
2025-01-17 - club - MLT - male - 1465817 - Negombo Cricket Club vs Police Sports Club
2025-01-10 - club - MLT - male - 1465816 - Nondescripts Cricket Club vs Tamil Union Cricket and Athletic Club
2025-01-10 - club - MLT - male - 1465815 - Burgher Recreation Club vs Kurunegala Youth Cricket Club
2025-01-10 - club - MLT - male - 1465814 - Nugegoda Sports Welfare Club vs Colombo Cricket Club
2025-01-10 - club - MLT - male - 1465813 - Kandy Customs Cricket Club vs Sinhalese Sports Club
2025-01-10 - club - MLT - male - 1465812 - Colts Cricket Club vs Ace Capital Cricket Club
2025-01-10 - club - MLT - male - 1465811 - Ragama Cricket Club vs Panadura Sports Club
2025-01-10 - club - MLT - male - 1465810 - Chilaw Marians Cricket Club vs Negombo Cricket Club
2025-01-10 - club - MLT - male - 1465809 - Badureliya Sports Club vs Police Sports Club
2025-01-03 - club - MLT - male - 1465808 - Moors Sports Club vs Tamil Union Cricket and Athletic Club
2025-01-03 - club - MLT - male - 1465807 - Burgher Recreation Club vs Nondescripts Cricket Club
2025-01-03 - club - MLT - male - 1465806 - Kandy Customs Cricket Club vs Kurunegala Youth Cricket Club
2025-01-03 - club - MLT - male - 1465805 - Nugegoda Sports Welfare Club vs Sinhalese Sports Club
2025-01-03 - club - MLT - male - 1465804 - Colts Cricket Club vs Bloomfield Cricket and Athletic Club
2025-01-03 - club - MLT - male - 1465803 - Ace Capital Cricket Club vs Ragama Cricket Club
2025-01-03 - club - MLT - male - 1465802 - Badureliya Sports Club vs Panadura Sports Club
2025-01-03 - club - MLT - male - 1465801 - Chilaw Marians Cricket Club vs Police Sports Club
2024-12-27 - club - MLT - male - 1465800 - Burgher Recreation Club vs Moors Sports Club
2024-12-27 - club - MLT - male - 1465799 - Tamil Union Cricket and Athletic Club vs Colombo Cricket Club
2024-12-27 - club - MLT - male - 1465798 - Kandy Customs Cricket Club vs Nondescripts Cricket Club
2024-12-27 - club - MLT - male - 1465797 - Sinhalese Sports Club vs Kurunegala Youth Cricket Club
2024-12-27 - club - MLT - male - 1465796 - Ragama Cricket Club vs Bloomfield Cricket and Athletic Club
2024-12-27 - club - MLT - male - 1465795 - Negombo Cricket Club vs Colts Cricket Club
2024-12-27 - club - MLT - male - 1465794 - Badureliya Sports Club vs Ace Capital Cricket Club
2024-12-27 - club - MLT - male - 1465793 - Panadura Sports Club vs Police Sports Club
2024-12-07 - club - PKS - male - 1452148 - Otago Volts vs Canterbury
2024-12-07 - club - PKS - male - 1452147 - Northern Districts vs Central Stags
2024-12-07 - club - PKS - male - 1452146 - Auckland Aces vs Wellington Firebirds
2024-12-06 - club - SSH - male - 1444509 - South Australia vs Tasmania
2024-12-06 - club - SSH - male - 1444508 - Queensland vs Victoria
2024-12-06 - club - SSH - male - 1444507 - Western Australia vs New South Wales
2024-11-28 - club - PKS - male - 1452145 - Wellington Firebirds vs Central Stags
2024-11-28 - club - PKS - male - 1452144 - Otago Volts vs Northern Districts
2024-11-28 - club - PKS - male - 1452143 - Auckland Aces vs Canterbury
2024-11-24 - club - SSH - male - 1444506 - Victoria vs Queensland
2024-11-24 - club - SSH - male - 1444505 - Tasmania vs New South Wales
2024-11-23 - club - SSH - male - 1444504 - Western Australia vs South Australia
2024-11-19 - club - PKS - male - 1452142 - Wellington Firebirds vs Otago Volts
2024-11-19 - club - PKS - male - 1452141 - Central Stags vs Canterbury
2024-11-19 - club - PKS - male - 1452140 - Northern Districts vs Auckland Aces
2024-11-15 - club - SSH - male - 1444503 - Tasmania vs Queensland
2024-11-15 - club - SSH - male - 1444502 - Western Australia vs Victoria
2024-11-14 - club - SSH - male - 1444501 - South Australia vs New South Wales
2024-11-11 - club - PKS - male - 1452139 - Canterbury vs Northern Districts
2024-11-11 - club - PKS - male - 1452138 - Auckland Aces vs Wellington Firebirds
2024-11-11 - club - PKS - male - 1452137 - Otago Volts vs Central Stags
2024-11-01 - club - SSH - male - 1444500 - South Australia vs Victoria
2024-11-01 - club - SSH - male - 1444499 - Tasmania vs Western Australia
2024-11-01 - club - SSH - male - 1444498 - New South Wales vs Queensland
2024-10-20 - club - SSH - male - 1444497 - Tasmania vs Western Australia
2024-10-20 - club - SSH - male - 1444496 - South Australia vs Queensland
2024-10-20 - club - SSH - male - 1444495 - Victoria vs New South Wales
2024-10-08 - club - SSH - male - 1444494 - Western Australia vs Queensland
2024-10-08 - club - SSH - male - 1444493 - Victoria vs Tasmania
2024-10-08 - club - SSH - male - 1444492 - New South Wales vs South Australia
2024-09-26 - club - CCH - male - 1410318 - Northamptonshire vs Yorkshire
2024-09-26 - club - CCH - male - 1410317 - Middlesex vs Sussex
2024-09-26 - club - CCH - male - 1410316 - Leicestershire vs Derbyshire
2024-09-26 - club - CCH - male - 1410315 - Glamorgan vs Gloucestershire
2024-09-26 - club - CCH - male - 1410262 - Worcestershire vs Lancashire
2024-09-26 - club - CCH - male - 1410261 - Somerset vs Hampshire
2024-09-26 - club - CCH - male - 1410260 - Nottinghamshire vs Warwickshire
2024-09-26 - club - CCH - male - 1410259 - Essex vs Surrey
2024-09-26 - club - CCH - male - 1410258 - Durham vs Kent
2024-09-17 - club - CCH - male - 1410314 - Leicestershire vs Northamptonshire
2024-09-17 - club - CCH - male - 1410313 - Gloucestershire vs Sussex
2024-09-17 - club - CCH - male - 1410312 - Yorkshire vs Glamorgan
2024-09-17 - club - CCH - male - 1410311 - Derbyshire vs Middlesex
2024-09-17 - club - CCH - male - 1410257 - Warwickshire vs Essex
2024-09-17 - club - CCH - male - 1410256 - Durham vs Surrey
2024-09-17 - club - CCH - male - 1410255 - Lancashire vs Somerset
2024-09-17 - club - CCH - male - 1410254 - Nottinghamshire vs Kent
2024-09-17 - club - CCH - male - 1410253 - Hampshire vs Worcestershire
2024-09-09 - club - CCH - male - 1410310 - Glamorgan vs Sussex
2024-09-09 - club - CCH - male - 1410309 - Northamptonshire vs Derbyshire
2024-09-09 - club - CCH - male - 1410308 - Middlesex vs Gloucestershire
2024-09-09 - club - CCH - male - 1410307 - Leicestershire vs Yorkshire
2024-09-09 - club - CCH - male - 1410252 - Worcestershire vs Warwickshire
2024-09-09 - club - CCH - male - 1410251 - Somerset vs Surrey
2024-09-09 - club - CCH - male - 1410250 - Hampshire vs Kent
2024-09-09 - club - CCH - male - 1410249 - Essex vs Nottinghamshire
2024-09-09 - club - CCH - male - 1410248 - Lancashire vs Durham
2024-08-29 - club - CCH - male - 1410306 - Yorkshire vs Middlesex
2024-08-29 - club - CCH - male - 1410305 - Sussex vs Derbyshire
2024-08-29 - club - CCH - male - 1410304 - Gloucestershire vs Northamptonshire
2024-08-29 - club - CCH - male - 1410303 - Leicestershire vs Glamorgan
2024-08-29 - club - CCH - male - 1410247 - Kent vs Warwickshire
2024-08-29 - club - CCH - male - 1410246 - Somerset vs Durham
2024-08-29 - club - CCH - male - 1410245 - Surrey vs Nottinghamshire
2024-08-29 - club - CCH - male - 1410244 - Hampshire vs Lancashire
2024-08-29 - club - CCH - male - 1410243 - Worcestershire vs Essex
2024-08-22 - club - CCH - male - 1410302 - Sussex vs Yorkshire
2024-08-22 - club - CCH - male - 1410301 - Northamptonshire vs Middlesex
2024-08-22 - club - CCH - male - 1410300 - Leicestershire vs Gloucestershire
2024-08-22 - club - CCH - male - 1410299 - Glamorgan vs Derbyshire
2024-08-22 - club - CCH - male - 1410242 - Kent vs Worcestershire
2024-08-22 - club - CCH - male - 1410241 - Warwickshire vs Somerset
2024-08-22 - club - CCH - male - 1410240 - Lancashire vs Surrey
2024-08-22 - club - CCH - male - 1410239 - Essex vs Hampshire
2024-08-22 - club - CCH - male - 1410238 - Durham vs Nottinghamshire
2024-06-30 - club - CCH - male - 1410298 - Sussex vs Northamptonshire
2024-06-30 - club - CCH - male - 1410297 - Leicestershire vs Middlesex
2024-06-30 - club - CCH - male - 1410296 - Gloucestershire vs Glamorgan
2024-06-30 - club - CCH - male - 1410295 - Derbyshire vs Yorkshire
2024-06-30 - club - CCH - male - 1410237 - Surrey vs Essex
2024-06-30 - club - CCH - male - 1410236 - Warwickshire vs Somerset
2024-06-30 - club - CCH - male - 1410235 - Lancashire vs Nottinghamshire
2024-06-30 - club - CCH - male - 1410234 - Hampshire vs Kent
2024-06-30 - club - CCH - male - 1410233 - Durham vs Worcestershire
2024-06-23 - club - CCH - male - 1410294 - Yorkshire vs Gloucestershire
2024-06-23 - club - CCH - male - 1410293 - Sussex vs Leicestershire
2024-06-23 - club - CCH - male - 1410292 - Middlesex vs Derbyshire
2024-06-23 - club - CCH - male - 1410291 - Northamptonshire vs Glamorgan
2024-06-23 - club - CCH - male - 1410232 - Surrey vs Worcestershire
2024-06-23 - club - CCH - male - 1410231 - Hampshire vs Warwickshire
2024-06-23 - club - CCH - male - 1410230 - Nottinghamshire vs Somerset
2024-06-23 - club - CCH - male - 1410229 - Kent vs Lancashire
2024-06-23 - club - CCH - male - 1410228 - Durham vs Essex
2024-05-24 - club - CCH - male - 1410290 - Yorkshire vs Northamptonshire
2024-05-24 - club - CCH - male - 1410289 - Sussex vs Middlesex
2024-05-24 - club - CCH - male - 1410288 - Glamorgan vs Leicestershire
2024-05-24 - club - CCH - male - 1410287 - Derbyshire vs Gloucestershire
2024-05-24 - club - CCH - male - 1410227 - Worcestershire vs Nottinghamshire
2024-05-24 - club - CCH - male - 1410226 - Warwickshire vs Lancashire
2024-05-24 - club - CCH - male - 1410225 - Essex vs Kent
2024-05-24 - club - CCH - male - 1410224 - Surrey vs Hampshire
2024-05-24 - club - CCH - male - 1410223 - Somerset vs Durham
2024-05-17 - club - CCH - male - 1410286 - Sussex vs Yorkshire
2024-05-17 - club - CCH - male - 1410285 - Gloucestershire vs Leicestershire
2024-05-17 - club - CCH - male - 1410284 - Glamorgan vs Middlesex
2024-05-17 - club - CCH - male - 1410283 - Northamptonshire vs Derbyshire
2024-05-17 - club - CCH - male - 1410222 - Surrey vs Worcestershire
2024-05-17 - club - CCH - male - 1410221 - Somerset vs Kent
2024-05-17 - club - CCH - male - 1410220 - Nottinghamshire vs Hampshire
2024-05-17 - club - CCH - male - 1410219 - Lancashire vs Durham
2024-05-17 - club - CCH - male - 1410218 - Warwickshire vs Essex
2024-05-10 - club - CCH - male - 1410282 - Gloucestershire vs Northamptonshire
2024-05-10 - club - CCH - male - 1410281 - Sussex vs Glamorgan
2024-05-10 - club - CCH - male - 1410217 - Warwickshire vs Surrey
2024-05-10 - club - CCH - male - 1410216 - Lancashire vs Nottinghamshire
2024-05-10 - club - CCH - male - 1410215 - Worcestershire vs Kent
2024-05-10 - club - CCH - male - 1410214 - Hampshire vs Durham
2024-05-03 - club - CCH - male - 1410280 - Glamorgan vs Yorkshire
2024-05-03 - club - CCH - male - 1410279 - Leicestershire vs Middlesex
2024-05-03 - club - CCH - male - 1410278 - Derbyshire vs Sussex
2024-05-03 - club - CCH - male - 1410213 - Essex vs Somerset
2024-05-03 - club - CCH - male - 1410212 - Kent vs Lancashire
2024-04-26 - club - CCH - male - 1410277 - Yorkshire vs Derbyshire
2024-04-26 - club - CCH - male - 1410276 - Northamptonshire vs Leicestershire
2024-04-26 - club - CCH - male - 1410275 - Middlesex vs Gloucestershire
2024-04-26 - club - CCH - male - 1410211 - Somerset vs Worcestershire
2024-04-26 - club - CCH - male - 1410210 - Nottinghamshire vs Warwickshire
2024-04-26 - club - CCH - male - 1410209 - Hampshire vs Surrey
2024-04-26 - club - CCH - male - 1410208 - Durham vs Essex
2024-04-19 - club - CCH - male - 1410274 - Gloucestershire vs Sussex
2024-04-19 - club - CCH - male - 1410273 - Glamorgan vs Northamptonshire
2024-04-19 - club - CCH - male - 1410272 - Yorkshire vs Middlesex
2024-04-19 - club - CCH - male - 1410271 - Leicestershire vs Derbyshire
2024-04-19 - club - CCH - male - 1410207 - Durham vs Worcestershire
2024-04-19 - club - CCH - male - 1410206 - Nottinghamshire vs Somerset
2024-04-19 - club - CCH - male - 1410205 - Kent vs Surrey
2024-04-19 - club - CCH - male - 1410204 - Warwickshire vs Hampshire
2024-04-19 - club - CCH - male - 1410203 - Lancashire vs Essex
2024-04-12 - club - CCH - male - 1410270 - Northamptonshire vs Middlesex
2024-04-12 - club - CCH - male - 1410269 - Leicestershire vs Sussex
2024-04-12 - club - CCH - male - 1410268 - Yorkshire vs Gloucestershire
2024-04-12 - club - CCH - male - 1410267 - Glamorgan vs Derbyshire
2024-04-12 - club - CCH - male - 1410202 - Warwickshire vs Durham
2024-04-12 - club - CCH - male - 1410201 - Somerset vs Surrey
2024-04-12 - club - CCH - male - 1410200 - Nottinghamshire vs Worcestershire
2024-04-12 - club - CCH - male - 1410199 - Hampshire vs Lancashire
2024-04-12 - club - CCH - male - 1410198 - Essex vs Kent
2024-04-05 - club - CCH - male - 1410266 - Leicestershire vs Yorkshire
2024-04-05 - club - CCH - male - 1410265 - Northamptonshire vs Sussex
2024-04-05 - club - CCH - male - 1410264 - Glamorgan vs Middlesex
2024-04-05 - club - CCH - male - 1410197 - Worcestershire vs Warwickshire
2024-04-05 - club - CCH - male - 1410196 - Essex vs Nottinghamshire
2024-04-05 - club - CCH - male - 1410195 - Lancashire vs Surrey
2024-04-05 - club - CCH - male - 1410194 - Kent vs Somerset
2024-03-24 - club - PKS - male - 1391926 - Central Stags vs Otago Volts
2024-03-24 - club - PKS - male - 1391925 - Northern Districts vs Wellington Firebirds
2024-03-24 - club - PKS - male - 1391924 - Auckland Aces vs Canterbury
2024-03-21 - club - SSH - male - 1391800 - Western Australia vs Tasmania
2024-03-16 - club - PKS - male - 1391923 - Canterbury vs Northern Districts
2024-03-16 - club - PKS - male - 1391922 - Wellington Firebirds vs Otago Volts
2024-03-16 - club - PKS - male - 1391921 - Central Stags vs Auckland Aces
2024-03-11 - club - SSH - male - 1391799 - Queensland vs New South Wales
2024-03-11 - club - SSH - male - 1391798 - Western Australia vs Victoria
2024-03-11 - club - SSH - male - 1391797 - South Australia vs Tasmania
2024-03-08 - club - PKS - male - 1391920 - Otago Volts vs Canterbury
2024-03-08 - club - PKS - male - 1391919 - Central Stags vs Wellington Firebirds
2024-03-08 - club - PKS - male - 1391918 - Northern Districts vs Auckland Aces
2024-03-01 - club - SSH - male - 1391796 - Western Australia vs Queensland
2024-03-01 - club - SSH - male - 1391795 - Tasmania vs Victoria
2024-03-01 - club - SSH - male - 1391794 - South Australia vs New South Wales
2024-02-29 - club - PKS - male - 1391917 - Otago Volts vs Auckland Aces
2024-02-29 - club - PKS - male - 1391916 - Canterbury vs Wellington Firebirds
2024-02-29 - club - PKS - male - 1391915 - Northern Districts vs Central Stags
2024-02-16 - club - SSH - male - 1391793 - South Australia vs Queensland
2024-02-16 - club - SSH - male - 1391792 - Tasmania vs Western Australia
2024-02-16 - club - SSH - male - 1391791 - New South Wales vs Victoria
2024-02-03 - club - SSH - male - 1391790 - Western Australia vs New South Wales
2024-02-03 - club - SSH - male - 1391789 - Queensland vs Tasmania
2024-02-03 - club - SSH - male - 1391788 - South Australia vs Victoria
2023-11-28 - club - SSH - male - 1391787 - Queensland vs Western Australia
2023-11-28 - club - SSH - male - 1391786 - New South Wales vs Tasmania
2023-11-28 - club - SSH - male - 1391785 - Victoria vs South Australia
2023-11-18 - club - SSH - male - 1391784 - New South Wales vs Tasmania
2023-11-16 - club - SSH - male - 1391783 - Victoria vs Queensland
2023-11-15 - club - SSH - male - 1391782 - South Australia vs Western Australia
2023-11-15 - club - PKS - male - 1391914 - Otago Volts vs Northern Districts
2023-11-15 - club - PKS - male - 1391913 - Central Stags vs Canterbury
2023-11-15 - club - PKS - male - 1391912 - Auckland Aces vs Wellington Firebirds
2023-11-06 - club - SSH - male - 1391781 - South Australia vs Queensland
2023-11-06 - club - SSH - male - 1391780 - Western Australia vs New South Wales
2023-11-06 - club - PKS - male - 1391911 - Otago Volts vs Central Stags
2023-11-06 - club - PKS - male - 1391910 - Canterbury vs Auckland Aces
2023-11-06 - club - PKS - male - 1391909 - Wellington Firebirds vs Northern Districts
2023-11-05 - club - SSH - male - 1391779 - Tasmania vs Victoria
2023-10-28 - club - PKS - male - 1391908 - Canterbury vs Otago Volts
2023-10-28 - club - PKS - male - 1391907 - Central Stags vs Wellington Firebirds
2023-10-28 - club - PKS - male - 1391906 - Auckland Aces vs Northern Districts
2023-10-26 - club - SSH - male - 1391778 - Western Australia vs South Australia
2023-10-26 - club - SSH - male - 1391777 - Queensland vs Tasmania
2023-10-26 - club - SSH - male - 1391776 - Victoria vs New South Wales
2023-10-20 - club - PKS - male - 1391905 - Wellington Firebirds vs Canterbury
2023-10-20 - club - PKS - male - 1391904 - Northern Districts vs Otago Volts
2023-10-20 - club - PKS - male - 1391903 - Auckland Aces vs Central Stags
2023-10-15 - club - SSH - male - 1391775 - Tasmania vs Western Australia
2023-10-15 - club - SSH - male - 1391774 - South Australia vs New South Wales
2023-10-14 - club - SSH - male - 1391773 - Victoria vs Queensland
2023-10-04 - club - SSH - male - 1391772 - Victoria vs Western Australia
2023-10-04 - club - SSH - male - 1391771 - Queensland vs New South Wales
2023-10-03 - club - SSH - male - 1391770 - South Australia vs Tasmania
2023-09-26 - club - CCH - male - 1347275 - Northamptonshire vs Essex
2023-09-26 - club - CCH - male - 1347274 - Lancashire vs Kent
2023-09-26 - club - CCH - male - 1347273 - Hampshire vs Surrey
2023-09-26 - club - CCH - male - 1347272 - Middlesex vs Nottinghamshire
2023-09-26 - club - CCH - male - 1347271 - Somerset vs Warwickshire
2023-09-26 - club - CCH - male - 1347205 - Worcestershire vs Yorkshire
2023-09-26 - club - CCH - male - 1347204 - Sussex vs Gloucestershire
2023-09-26 - club - CCH - male - 1347203 - Derbyshire vs Glamorgan
2023-09-26 - club - CCH - male - 1347202 - Durham vs Leicestershire
2023-09-19 - club - CCH - male - 1347270 - Somerset vs Kent
2023-09-19 - club - CCH - male - 1347269 - Essex vs Hampshire
2023-09-19 - club - CCH - male - 1347268 - Lancashire vs Nottinghamshire
2023-09-19 - club - CCH - male - 1347267 - Middlesex vs Warwickshire
2023-09-19 - club - CCH - male - 1347266 - Northamptonshire vs Surrey
2023-09-19 - club - CCH - male - 1347201 - Yorkshire vs Leicestershire
2023-09-19 - club - CCH - male - 1347200 - Worcestershire vs Durham
2023-09-19 - club - CCH - male - 1347199 - Sussex vs Derbyshire
2023-09-10 - club - CCH - male - 1347265 - Middlesex vs Lancashire
2023-09-10 - club - CCH - male - 1347264 - Northamptonshire vs Warwickshire
2023-09-10 - club - CCH - male - 1347263 - Kent vs Nottinghamshire
2023-09-10 - club - CCH - male - 1347198 - Gloucestershire vs Derbyshire
2023-09-10 - club - CCH - male - 1347197 - Sussex vs Leicestershire
2023-09-10 - club - CCH - male - 1347196 - Yorkshire vs Glamorgan
2023-09-04 - club - CCH - male - 1347262 - Essex vs Middlesex
2023-09-03 - club - CCH - male - 1347261 - Northamptonshire vs Lancashire
2023-09-03 - club - CCH - male - 1347260 - Surrey vs Warwickshire
2023-09-03 - club - CCH - male - 1347259 - Hampshire vs Somerset
2023-09-03 - club - CCH - male - 1347195 - Gloucestershire vs Leicestershire
2023-09-03 - club - CCH - male - 1347194 - Yorkshire vs Derbyshire
2023-09-03 - club - CCH - male - 1347193 - Worcestershire vs Glamorgan
2023-09-03 - club - CCH - male - 1347192 - Sussex vs Durham
2023-07-26 - club - CCH - male - 1347191 - Worcestershire vs Gloucestershire
2023-07-25 - club - CCH - male - 1347258 - Somerset vs Surrey
2023-07-25 - club - CCH - male - 1347257 - Nottinghamshire vs Kent
2023-07-25 - club - CCH - male - 1347256 - Northamptonshire vs Lancashire
2023-07-25 - club - CCH - male - 1347255 - Warwickshire vs Middlesex
2023-07-25 - club - CCH - male - 1347254 - Hampshire vs Essex
2023-07-25 - club - CCH - male - 1347190 - Yorkshire vs Durham
2023-07-25 - club - CCH - male - 1347189 - Glamorgan vs Derbyshire
2023-07-20 - club - CCH - male - 1347188 - Glamorgan vs Gloucestershire
2023-07-19 - club - CCH - male - 1347253 - Somerset vs Northamptonshire
2023-07-19 - club - CCH - male - 1347252 - Kent vs Essex
2023-07-19 - club - CCH - male - 1347251 - Surrey vs Middlesex
2023-07-19 - club - CCH - male - 1347250 - Hampshire vs Nottinghamshire
2023-07-19 - club - CCH - male - 1347249 - Lancashire vs Warwickshire
2023-07-19 - club - CCH - male - 1347187 - Worcestershire vs Leicestershire
2023-07-19 - club - CCH - male - 1347186 - Derbyshire vs Durham
2023-07-19 - club - CCH - male - 1347185 - Sussex vs Yorkshire
2023-07-10 - club - CCH - male - 1347248 - Essex vs Lancashire
2023-07-10 - club - CCH - male - 1347247 - Somerset vs Hampshire
2023-07-10 - club - CCH - male - 1347246 - Kent vs Warwickshire
2023-07-10 - club - CCH - male - 1347245 - Northamptonshire vs Middlesex
2023-07-10 - club - CCH - male - 1347244 - Surrey vs Nottinghamshire
2023-07-10 - club - CCH - male - 1347184 - Gloucestershire vs Durham
2023-07-10 - club - CCH - male - 1347183 - Yorkshire vs Worcestershire
2023-07-10 - club - CCH - male - 1347182 - Sussex vs Derbyshire
2023-07-10 - club - CCH - male - 1347181 - Glamorgan vs Leicestershire
2023-06-25 - club - CCH - male - 1347243 - Somerset vs Nottinghamshire
2023-06-25 - club - CCH - male - 1347242 - Essex vs Warwickshire
2023-06-25 - club - CCH - male - 1347241 - Lancashire vs Surrey
2023-06-25 - club - CCH - male - 1347240 - Northamptonshire vs Kent
2023-06-25 - club - CCH - male - 1347239 - Hampshire vs Middlesex
2023-06-25 - club - CCH - male - 1347180 - Durham vs Leicestershire
2023-06-25 - club - CCH - male - 1347179 - Worcestershire vs Derbyshire
2023-06-25 - club - CCH - male - 1347178 - Yorkshire vs Gloucestershire
2023-06-25 - club - CCH - male - 1347177 - Glamorgan vs Sussex
2023-06-11 - club - CCH - male - 1347238 - Kent vs Surrey
2023-06-11 - club - CCH - male - 1347237 - Warwickshire vs Nottinghamshire
2023-06-11 - club - CCH - male - 1347236 - Essex vs Somerset
2023-06-11 - club - CCH - male - 1347235 - Hampshire vs Lancashire
2023-06-11 - club - CCH - male - 1347176 - Sussex vs Worcestershire
2023-06-11 - club - CCH - male - 1347175 - Derbyshire vs Yorkshire
2023-06-11 - club - CCH - male - 1347174 - Gloucestershire vs Leicestershire
2023-06-11 - club - CCH - male - 1347173 - Glamorgan vs Durham
2023-05-18 - club - CCH - male - 1347234 - Essex vs Nottinghamshire
2023-05-18 - club - CCH - male - 1347233 - Somerset vs Middlesex
2023-05-18 - club - CCH - male - 1347232 - Kent vs Surrey
2023-05-18 - club - CCH - male - 1347231 - Hampshire vs Northamptonshire
2023-05-18 - club - CCH - male - 1347172 - Durham vs Gloucestershire
2023-05-18 - club - CCH - male - 1347171 - Glamorgan vs Sussex
2023-05-18 - club - CCH - male - 1347170 - Leicestershire vs Worcestershire
2023-05-11 - club - CCH - male - 1347230 - Kent vs Hampshire
2023-05-11 - club - CCH - male - 1347229 - Northamptonshire vs Nottinghamshire
2023-05-11 - club - CCH - male - 1347228 - Middlesex vs Surrey
2023-05-11 - club - CCH - male - 1347227 - Somerset vs Lancashire
2023-05-11 - club - CCH - male - 1347226 - Essex vs Warwickshire
2023-05-11 - club - CCH - male - 1347169 - Sussex vs Leicestershire
2023-05-11 - club - CCH - male - 1347168 - Worcestershire vs Glamorgan
2023-05-11 - club - CCH - male - 1347167 - Derbyshire vs Gloucestershire
2023-05-11 - club - CCH - male - 1347166 - Yorkshire vs Durham
2023-05-04 - club - CCH - male - 1347225 - Essex vs Surrey
2023-05-04 - club - CCH - male - 1347224 - Northamptonshire vs Somerset
2023-05-04 - club - CCH - male - 1347223 - Lancashire vs Nottinghamshire
2023-05-04 - club - CCH - male - 1347222 - Hampshire vs Warwickshire
2023-05-04 - club - CCH - male - 1347165 - Glamorgan vs Yorkshire
2023-05-04 - club - CCH - male - 1347164 - Leicestershire vs Derbyshire
2023-05-04 - club - CCH - male - 1347163 - Worcestershire vs Sussex
2023-04-27 - club - CCH - male - 1347221 - Warwickshire vs Surrey
2023-04-27 - club - CCH - male - 1347220 - Kent vs Middlesex
2023-04-27 - club - CCH - male - 1347162 - Leicestershire vs Glamorgan
2023-04-27 - club - CCH - male - 1347161 - Sussex vs Gloucestershire
2023-04-27 - club - CCH - male - 1347160 - Durham vs Derbyshire
2023-04-20 - club - CCH - male - 1347219 - Essex vs Kent
2023-04-20 - club - CCH - male - 1347218 - Hampshire vs Northamptonshire
2023-04-20 - club - CCH - male - 1347217 - Somerset vs Lancashire
2023-04-20 - club - CCH - male - 1347216 - Nottinghamshire vs Middlesex
2023-04-20 - club - CCH - male - 1347159 - Sussex vs Yorkshire
2023-04-20 - club - CCH - male - 1347158 - Durham vs Glamorgan
2023-04-20 - club - CCH - male - 1347157 - Gloucestershire vs Worcestershire
2023-04-13 - club - CCH - male - 1347215 - Middlesex vs Northamptonshire
2023-04-13 - club - CCH - male - 1347214 - Lancashire vs Essex
2023-04-13 - club - CCH - male - 1347213 - Nottinghamshire vs Somerset
2023-04-13 - club - CCH - male - 1347212 - Hampshire vs Surrey
2023-04-13 - club - CCH - male - 1347211 - Warwickshire vs Kent
2023-04-13 - club - CCH - male - 1347156 - Leicestershire vs Derbyshire
2023-04-13 - club - CCH - male - 1347155 - Durham vs Worcestershire
2023-04-06 - club - CCH - male - 1347210 - Northamptonshire vs Kent
2023-04-06 - club - CCH - male - 1347209 - Essex vs Middlesex
2023-04-06 - club - CCH - male - 1347208 - Somerset vs Warwickshire
2023-04-06 - club - CCH - male - 1347207 - Surrey vs Lancashire
2023-04-06 - club - CCH - male - 1347206 - Nottinghamshire vs Hampshire
2023-04-06 - club - CCH - male - 1347153 - Yorkshire vs Leicestershire
2023-04-06 - club - CCH - male - 1347152 - Derbyshire vs Worcestershire
2023-04-06 - club - CCH - male - 1347151 - Gloucestershire vs Glamorgan
2023-04-06 - club - CCH - male - 1347150 - Durham vs Sussex
2023-04-01 - club - PKS - male - 1328690 - Central Stags vs Auckland Aces
2023-03-23 - club - SSH - male - 1322426 - Victoria vs Western Australia
2023-03-21 - club - PKS - male - 1328700 - Canterbury vs Wellington Firebirds
2023-03-21 - club - PKS - male - 1328699 - Central Stags vs Otago Volts
2023-03-21 - club - PKS - male - 1328698 - Auckland Aces vs Northern Districts
2023-03-14 - club - SSH - male - 1322425 - Western Australia vs Victoria
2023-03-14 - club - SSH - male - 1322424 - New South Wales vs South Australia
2023-03-14 - club - SSH - male - 1322423 - Tasmania vs Queensland
2023-03-13 - club - PKS - male - 1328697 - Otago Volts vs Auckland Aces
2023-03-13 - club - PKS - male - 1328696 - Canterbury vs Central Stags
2023-03-13 - club - PKS - male - 1328695 - Northern Districts vs Wellington Firebirds
2023-03-06 - club - PKS - male - 1328694 - Otago Volts vs Canterbury
2023-03-05 - club - PKS - male - 1328693 - Northern Districts vs Central Stags
2023-03-05 - club - PKS - male - 1328692 - Auckland Aces vs Wellington Firebirds
2023-03-02 - club - SSH - male - 1322422 - Tasmania vs Western Australia
2023-03-02 - club - SSH - male - 1322421 - South Australia vs Queensland
2023-03-02 - club - SSH - male - 1322420 - New South Wales vs Victoria
2023-02-25 - club - PKS - male - 1328691 - Otago Volts vs Wellington Firebirds
2023-02-25 - club - PKS - male - 1328689 - Northern Districts vs Canterbury
2023-02-21 - club - SSH - male - 1322419 - New South Wales vs Queensland
2023-02-21 - club - SSH - male - 1322418 - Western Australia vs Tasmania
2023-02-20 - club - SSH - male - 1322417 - Victoria vs South Australia
2023-02-11 - club - SSH - male - 1322416 - New South Wales vs Tasmania
2023-02-10 - club - SSH - male - 1322415 - South Australia vs Western Australia
2023-02-09 - club - SSH - male - 1322414 - Victoria vs Queensland
2022-12-01 - club - SSH - male - 1322413 - Queensland vs Western Australia
2022-12-01 - club - SSH - male - 1322412 - South Australia vs Tasmania
2022-12-01 - club - SSH - male - 1322411 - Victoria vs New South Wales
2022-11-24 - club - SSH - male - 1322410 - Victoria vs Tasmania
2022-11-22 - club - SSH - male - 1322409 - Western Australia vs New South Wales
2022-11-20 - club - SSH - male - 1322408 - South Australia vs Queensland
2022-11-14 - club - PKS - male - 1328688 - Otago Volts vs Northern Districts
2022-11-14 - club - PKS - male - 1328687 - Canterbury vs Auckland Aces
2022-11-14 - club - PKS - male - 1328686 - Central Stags vs Wellington Firebirds
2022-11-12 - club - SSH - male - 1322407 - Tasmania vs New South Wales
2022-11-11 - club - SSH - male - 1322406 - South Australia vs Western Australia
2022-11-10 - club - SSH - male - 1322405 - Victoria vs Queensland
2022-11-05 - club - PKS - male - 1328685 - Canterbury vs Otago Volts
2022-11-05 - club - PKS - male - 1328684 - Wellington Firebirds vs Auckland Aces
2022-11-05 - club - PKS - male - 1328683 - Central Stags vs Northern Districts
2022-10-31 - club - SSH - male - 1322404 - Queensland vs Western Australia
2022-10-31 - club - SSH - male - 1322403 - New South Wales vs South Australia
2022-10-29 - club - SSH - male - 1322402 - Victoria vs Tasmania
2022-10-26 - club - PKS - male - 1328682 - Wellington Firebirds vs Canterbury
2022-10-26 - club - PKS - male - 1328681 - Northern Districts vs Otago Volts
2022-10-25 - club - PKS - male - 1328680 - Auckland Aces vs Central Stags
2022-10-18 - club - SSH - male - 1322401 - New South Wales vs Queensland
2022-10-18 - club - PKS - male - 1328679 - Wellington Firebirds vs Northern Districts
2022-10-18 - club - PKS - male - 1328678 - Auckland Aces vs Otago Volts
2022-10-18 - club - PKS - male - 1328677 - Central Stags vs Canterbury
2022-10-17 - club - SSH - male - 1322400 - Western Australia vs Victoria
2022-10-16 - club - SSH - male - 1322399 - South Australia vs Tasmania
2022-10-06 - club - SSH - male - 1322398 - Victoria vs South Australia
2022-10-06 - club - SSH - male - 1322397 - Tasmania vs Queensland
2022-10-03 - club - SSH - male - 1322396 - New South Wales vs Western Australia
2022-09-26 - club - CCH - male - 1297793 - Essex vs Northamptonshire
2022-09-26 - club - CCH - male - 1297792 - Lancashire vs Surrey
2022-09-26 - club - CCH - male - 1297791 - Warwickshire vs Hampshire
2022-09-26 - club - CCH - male - 1297790 - Gloucestershire vs Yorkshire
2022-09-26 - club - CCH - male - 1297789 - Leicestershire vs Derbyshire
2022-09-26 - club - CCH - male - 1297788 - Nottinghamshire vs Durham
2022-09-26 - club - CCH - male - 1297787 - Glamorgan vs Sussex
2022-09-26 - club - CCH - male - 1297786 - Worcestershire vs Middlesex
2022-09-26 - club - CCH - male - 1297785 - Somerset vs Kent
2022-09-20 - club - CCH - male - 1297784 - Kent vs Hampshire
2022-09-20 - club - CCH - male - 1297783 - Lancashire vs Essex
2022-09-20 - club - CCH - male - 1297782 - Worcestershire vs Nottinghamshire
2022-09-20 - club - CCH - male - 1297781 - Middlesex vs Leicestershire
2022-09-20 - club - CCH - male - 1297780 - Glamorgan vs Derbyshire
2022-09-20 - club - CCH - male - 1297779 - Sussex vs Durham
2022-09-20 - club - CCH - male - 1297778 - Somerset vs Northamptonshire
2022-09-20 - club - CCH - male - 1297777 - Warwickshire vs Gloucestershire
2022-09-20 - club - CCH - male - 1297776 - Surrey vs Yorkshire
2022-09-12 - club - CCH - male - 1297775 - Glamorgan vs Middlesex
2022-09-12 - club - CCH - male - 1297774 - Somerset vs Warwickshire
2022-09-12 - club - CCH - male - 1297773 - Northamptonshire vs Surrey
2022-09-12 - club - CCH - male - 1297772 - Leicestershire vs Durham
2022-09-12 - club - CCH - male - 1297771 - Sussex vs Worcestershire
2022-09-12 - club - CCH - male - 1297770 - Yorkshire vs Essex
2022-09-05 - club - CCH - male - 1297769 - Hampshire vs Northamptonshire
2022-09-05 - club - CCH - male - 1297768 - Essex vs Kent
2022-09-05 - club - CCH - male - 1297767 - Lancashire vs Yorkshire
2022-09-05 - club - CCH - male - 1297766 - Gloucestershire vs Somerset
2022-09-05 - club - CCH - male - 1297765 - Derbyshire vs Durham
2022-09-05 - club - CCH - male - 1297764 - Worcestershire vs Glamorgan
2022-09-05 - club - CCH - male - 1297763 - Nottinghamshire vs Leicestershire
2022-07-26 - club - CCH - male - 1297762 - Nottinghamshire vs Sussex
2022-07-25 - club - CCH - male - 1297761 - Warwickshire vs Surrey
2022-07-25 - club - CCH - male - 1297760 - Gloucestershire vs Northamptonshire
2022-07-25 - club - CCH - male - 1297759 - Yorkshire vs Hampshire
2022-07-25 - club - CCH - male - 1297758 - Essex vs Somerset
2022-07-25 - club - CCH - male - 1297757 - Durham vs Middlesex
2022-07-25 - club - CCH - male - 1297756 - Derbyshire vs Worcestershire
2022-07-25 - club - CCH - male - 1297755 - Lancashire vs Kent
2022-07-20 - club - CCH - male - 1297754 - Leicestershire vs Glamorgan
2022-07-19 - club - CCH - male - 1297753 - Northamptonshire vs Lancashire
2022-07-19 - club - CCH - male - 1297752 - Sussex vs Middlesex
2022-07-19 - club - CCH - male - 1297751 - Nottinghamshire vs Derbyshire
2022-07-19 - club - CCH - male - 1297750 - Kent vs Warwickshire
2022-07-19 - club - CCH - male - 1297749 - Essex vs Surrey
2022-07-19 - club - CCH - male - 1297748 - Somerset vs Yorkshire
2022-07-19 - club - CCH - male - 1297747 - Hampshire vs Gloucestershire
2022-07-11 - club - CCH - male - 1297746 - Glamorgan vs Nottinghamshire
2022-07-11 - club - CCH - male - 1297745 - Yorkshire vs Surrey
2022-07-11 - club - CCH - male - 1297744 - Northamptonshire vs Kent
2022-07-11 - club - CCH - male - 1297743 - Sussex vs Leicestershire
2022-07-11 - club - CCH - male - 1297742 - Derbyshire vs Durham
2022-07-11 - club - CCH - male - 1297741 - Middlesex vs Worcestershire
2022-07-11 - club - CCH - male - 1297740 - Gloucestershire vs Essex
2022-07-11 - club - CCH - male - 1297739 - Warwickshire vs Hampshire
2022-07-11 - club - CCH - male - 1297738 - Somerset vs Lancashire
2022-06-26 - club - CCH - male - 1297737 - Gloucestershire vs Lancashire
2022-06-26 - club - CCH - male - 1297736 - Northamptonshire vs Warwickshire
2022-06-26 - club - CCH - male - 1297735 - Essex vs Hampshire
2022-06-26 - club - CCH - male - 1297734 - Worcestershire vs Glamorgan
2022-06-26 - club - CCH - male - 1297733 - Derbyshire vs Sussex
2022-06-26 - club - CCH - male - 1297732 - Nottinghamshire vs Middlesex
2022-06-26 - club - CCH - male - 1297731 - Surrey vs Kent
2022-06-12 - club - CCH - male - 1297730 - Middlesex vs Derbyshire
2022-06-12 - club - CCH - male - 1297729 - Leicestershire vs Nottinghamshire
2022-06-12 - club - CCH - male - 1297728 - Gloucestershire vs Kent
2022-06-12 - club - CCH - male - 1297727 - Warwickshire vs Lancashire
2022-06-12 - club - CCH - male - 1297726 - Durham vs Worcestershire
2022-06-12 - club - CCH - male - 1297725 - Yorkshire vs Hampshire
2022-06-12 - club - CCH - male - 1297724 - Sussex vs Glamorgan
2022-06-12 - club - CCH - male - 1297723 - Somerset vs Surrey
2022-05-19 - club - CCH - male - 1297722 - Essex vs Lancashire
2022-05-19 - club - CCH - male - 1297721 - Leicestershire vs Worcestershire
2022-05-19 - club - CCH - male - 1297720 - Derbyshire vs Nottinghamshire
2022-05-19 - club - CCH - male - 1297719 - Durham vs Middlesex
2022-05-19 - club - CCH - male - 1297718 - Warwickshire vs Yorkshire
2022-05-19 - club - CCH - male - 1297717 - Somerset vs Hampshire
2022-05-19 - club - CCH - male - 1297716 - Kent vs Northamptonshire
2022-05-12 - club - CCH - male - 1297715 - Somerset vs Gloucestershire
2022-05-12 - club - CCH - male - 1297714 - Nottinghamshire vs Middlesex
2022-05-12 - club - CCH - male - 1297713 - Leicestershire vs Sussex
2022-05-12 - club - CCH - male - 1297712 - Durham vs Glamorgan
2022-05-12 - club - CCH - male - 1297711 - Worcestershire vs Derbyshire
2022-05-12 - club - CCH - male - 1297710 - Lancashire vs Yorkshire
2022-05-12 - club - CCH - male - 1297709 - Surrey vs Kent
2022-05-12 - club - CCH - male - 1297708 - Northamptonshire vs Warwickshire
2022-05-05 - club - CCH - male - 1297707 - Essex vs Yorkshire
2022-05-05 - club - CCH - male - 1297706 - Durham vs Worcestershire
2022-05-05 - club - CCH - male - 1297705 - Sussex vs Middlesex
2022-05-05 - club - CCH - male - 1297704 - Leicestershire vs Glamorgan
2022-05-05 - club - CCH - male - 1297703 - Surrey vs Northamptonshire
2022-05-05 - club - CCH - male - 1297702 - Hampshire vs Gloucestershire
2022-05-05 - club - CCH - male - 1297701 - Warwickshire vs Lancashire
2022-04-28 - club - CCH - male - 1297700 - Leicestershire vs Middlesex
2022-04-28 - club - CCH - male - 1297699 - Durham vs Sussex
2022-04-28 - club - CCH - male - 1297698 - Derbyshire vs Glamorgan
2022-04-28 - club - CCH - male - 1297697 - Kent vs Yorkshire
2022-04-28 - club - CCH - male - 1297696 - Somerset vs Warwickshire
2022-04-28 - club - CCH - male - 1297695 - Hampshire vs Lancashire
2022-04-28 - club - CCH - male - 1297694 - Surrey vs Gloucestershire
2022-04-28 - club - CCH - male - 1297693 - Northamptonshire vs Essex
2022-04-28 - club - CCH - male - 1297692 - Worcestershire vs Nottinghamshire
2022-04-21 - club - CCH - male - 1297691 - Yorkshire vs Northamptonshire
2022-04-21 - club - CCH - male - 1297690 - Gloucestershire vs Lancashire
2022-04-21 - club - CCH - male - 1297689 - Somerset vs Surrey
2022-04-21 - club - CCH - male - 1297688 - Essex vs Warwickshire
2022-04-21 - club - CCH - male - 1297687 - Glamorgan vs Middlesex
2022-04-21 - club - CCH - male - 1297686 - Leicestershire vs Derbyshire
2022-04-21 - club - CCH - male - 1297685 - Worcestershire vs Sussex
2022-04-21 - club - CCH - male - 1297684 - Kent vs Hampshire
2022-04-21 - club - CCH - male - 1297683 - Durham vs Nottinghamshire
2022-04-14 - club - CCH - male - 1297682 - Surrey vs Hampshire
2022-04-14 - club - CCH - male - 1297681 - Gloucestershire vs Yorkshire
2022-04-14 - club - CCH - male - 1297680 - Somerset vs Essex
2022-04-14 - club - CCH - male - 1297679 - Derbyshire vs Sussex
2022-04-14 - club - CCH - male - 1297678 - Durham vs Leicestershire
2022-04-14 - club - CCH - male - 1297677 - Nottinghamshire vs Glamorgan
2022-04-14 - club - CCH - male - 1297676 - Lancashire vs Kent
2022-04-12 - club - PKS - male - 1279987 - Canterbury vs Auckland Aces
2022-04-07 - club - CCH - male - 1297675 - Essex vs Kent
2022-04-07 - club - CCH - male - 1297674 - Sussex vs Nottinghamshire
2022-04-07 - club - CCH - male - 1297673 - Middlesex vs Derbyshire
2022-04-07 - club - CCH - male - 1297672 - Worcestershire vs Leicestershire
2022-04-07 - club - CCH - male - 1297671 - Glamorgan vs Durham
2022-04-07 - club - CCH - male - 1297670 - Surrey vs Warwickshire
2022-04-07 - club - CCH - male - 1297669 - Gloucestershire vs Northamptonshire
2022-04-07 - club - CCH - male - 1297668 - Somerset vs Hampshire
2022-04-06 - club - PKS - male - 1279991 - Northern Districts vs Wellington Firebirds
2022-04-05 - club - PKS - male - 1279980 - Auckland Aces vs Central Stags
2022-03-31 - club - SSH - male - 1270465 - Western Australia vs Victoria
2022-03-29 - club - PKS - male - 1280010 - Canterbury vs Otago Volts
2022-03-29 - club - PKS - male - 1280009 - Northern Districts vs Central Stags
2022-03-28 - club - PKS - male - 1280008 - Auckland Aces vs Wellington Firebirds
2022-03-23 - club - SSH - male - 1270461 - Victoria vs Western Australia
2022-03-23 - club - SSH - male - 1270455 - Queensland vs Tasmania
2022-03-23 - club - SSH - male - 1270438 - New South Wales vs South Australia
2022-03-20 - club - PKS - male - 1280007 - Wellington Firebirds vs Otago Volts
2022-03-20 - club - PKS - male - 1280006 - Canterbury vs Central Stags
2022-03-15 - club - SSH - male - 1270445 - Western Australia vs New South Wales
2022-03-15 - club - SSH - male - 1270440 - Tasmania vs Victoria
2022-03-11 - club - PKS - male - 1280002 - Northern Districts vs Central Stags
2022-03-11 - club - PKS - male - 1279993 - Auckland Aces vs Otago Volts
2022-03-03 - club - PKS - male - 1280000 - Northern Districts vs Wellington Firebirds
2022-03-03 - club - PKS - male - 1279999 - Auckland Aces vs Canterbury
2022-02-18 - club - SSH - male - 1270453 - Queensland vs Victoria
2022-02-18 - club - SSH - male - 1270447 - New South Wales vs Tasmania
2022-02-11 - club - PKS - male - 1280004 - Auckland Aces vs Otago Volts
2022-02-09 - club - SSH - male - 1270459 - Queensland vs New South Wales
2022-02-09 - club - SSH - male - 1270451 - South Australia vs Victoria
2022-02-04 - club - PKS - male - 1279996 - Northern Districts vs Auckland Aces
2021-11-23 - club - SSH - male - 1270441 - Queensland vs South Australia
2021-11-22 - club - PKS - male - 1279995 - Otago Volts vs Northern Districts
2021-11-20 - club - SSH - male - 1270462 - New South Wales vs Victoria
2021-11-15 - club - PKS - male - 1279998 - Wellington Firebirds vs Central Stags
2021-11-15 - club - PKS - male - 1279997 - Northern Districts vs Canterbury
2021-11-10 - club - SSH - male - 1270456 - Queensland vs Western Australia
2021-11-10 - club - SSH - male - 1270446 - South Australia vs Tasmania
2021-11-07 - club - PKS - male - 1280003 - Canterbury vs Wellington Firebirds
2021-11-07 - club - PKS - male - 1280001 - Otago Volts vs Central Stags
2021-11-05 - club - SSH - male - 1270437 - Victoria vs New South Wales
2021-10-31 - club - PKS - male - 1279994 - Canterbury vs Wellington Firebirds
2021-10-31 - club - PKS - male - 1279992 - Central Stags vs Otago Volts
2021-10-27 - club - SSH - male - 1270442 - Victoria vs New South Wales
2021-10-23 - club - PKS - male - 1279990 - Central Stags vs Canterbury
2021-10-23 - club - PKS - male - 1279989 - Otago Volts vs Wellington Firebirds
2021-10-17 - club - SSH - male - 1270452 - Western Australia vs Tasmania
2021-10-15 - club - SSH - male - 1270448 - Queensland vs South Australia
2021-10-07 - club - SSH - male - 1270435 - Tasmania vs Queensland
2021-09-28 - club - BWT - male - 1279470 - Lancashire vs Warwickshire
2021-09-24 - club - SSH - male - 1270436 - Western Australia vs South Australia
2021-09-21 - club - CCH - male - 1271416 - Leicestershire vs Worcestershire
2021-09-21 - club - CCH - male - 1271415 - Derbyshire vs Sussex
2021-09-21 - club - CCH - male - 1271414 - Middlesex vs Kent
2021-09-21 - club - CCH - male - 1271413 - Glamorgan vs Surrey
2021-09-21 - club - CCH - male - 1271412 - Durham vs Gloucestershire
2021-09-21 - club - CCH - male - 1271411 - Northamptonshire vs Essex
2021-09-21 - club - CCH - male - 1271410 - Warwickshire vs Somerset
2021-09-21 - club - CCH - male - 1271409 - Nottinghamshire vs Yorkshire
2021-09-21 - club - CCH - male - 1271408 - Hampshire vs Lancashire
2021-09-12 - club - CCH - male - 1271407 - Middlesex vs Worcestershire
2021-09-12 - club - CCH - male - 1271406 - Sussex vs Leicestershire
2021-09-12 - club - CCH - male - 1271405 - Kent vs Derbyshire
2021-09-12 - club - CCH - male - 1271404 - Essex vs Surrey
2021-09-12 - club - CCH - male - 1271403 - Northamptonshire vs Durham
2021-09-12 - club - CCH - male - 1271402 - Glamorgan vs Gloucestershire
2021-09-12 - club - CCH - male - 1271401 - Warwickshire vs Yorkshire
2021-09-12 - club - CCH - male - 1271400 - Lancashire vs Somerset
2021-09-12 - club - CCH - male - 1271399 - Hampshire vs Nottinghamshire
2021-09-06 - club - CCH - male - 1271398 - Middlesex vs Sussex
2021-09-05 - club - CCH - male - 1271397 - Worcestershire vs Kent
2021-09-05 - club - CCH - male - 1271396 - Leicestershire vs Derbyshire
2021-09-05 - club - CCH - male - 1271395 - Surrey vs Northamptonshire
2021-09-05 - club - CCH - male - 1271394 - Gloucestershire vs Essex
2021-09-05 - club - CCH - male - 1271393 - Glamorgan vs Durham
2021-09-05 - club - CCH - male - 1271392 - Somerset vs Yorkshire
2021-09-05 - club - CCH - male - 1271391 - Hampshire vs Warwickshire
2021-09-05 - club - CCH - male - 1271390 - Nottinghamshire vs Lancashire
2021-08-30 - club - CCH - male - 1271389 - Sussex vs Worcestershire
2021-08-30 - club - CCH - male - 1271388 - Middlesex vs Derbyshire
2021-08-30 - club - CCH - male - 1271387 - Kent vs Leicestershire
2021-08-30 - club - CCH - male - 1271386 - Northamptonshire vs Gloucestershire
2021-08-30 - club - CCH - male - 1271385 - Glamorgan vs Essex
2021-08-30 - club - CCH - male - 1271383 - Nottinghamshire vs Somerset
2021-08-30 - club - CCH - male - 1271382 - Warwickshire vs Lancashire
2021-08-30 - club - CCH - male - 1271381 - Yorkshire vs Hampshire
2021-07-11 - club - CCH - male - 1244304 - Sussex vs Kent
2021-07-11 - club - CCH - male - 1244303 - Northamptonshire vs Glamorgan
2021-07-11 - club - CCH - male - 1244302 - Somerset vs Surrey
2021-07-11 - club - CCH - male - 1244301 - Middlesex vs Leicestershire
2021-07-11 - club - CCH - male - 1244300 - Gloucestershire vs Hampshire
2021-07-11 - club - CCH - male - 1244299 - Lancashire vs Yorkshire
2021-07-11 - club - CCH - male - 1244298 - Warwickshire vs Worcestershire
2021-07-11 - club - CCH - male - 1244297 - Nottinghamshire vs Durham
2021-07-11 - club - CCH - male - 1244296 - Derbyshire vs Essex
2021-07-05 - club - CCH - male - 1244290 - Gloucestershire vs Middlesex
2021-07-04 - club - CCH - male - 1244295 - Somerset vs Leicestershire
2021-07-04 - club - CCH - male - 1244294 - Hampshire vs Surrey
2021-07-04 - club - CCH - male - 1244293 - Warwickshire vs Durham
2021-07-04 - club - CCH - male - 1244292 - Derbyshire vs Nottinghamshire
2021-07-04 - club - CCH - male - 1244291 - Sussex vs Glamorgan
2021-07-04 - club - CCH - male - 1244289 - Yorkshire vs Northamptonshire
2021-07-04 - club - CCH - male - 1244288 - Kent vs Lancashire
2021-06-03 - club - CCH - male - 1244287 - Leicestershire vs Gloucestershire
2021-06-03 - club - CCH - male - 1244286 - Somerset vs Hampshire
2021-06-03 - club - CCH - male - 1244285 - Lancashire vs Glamorgan
2021-06-03 - club - CCH - male - 1244284 - Northamptonshire vs Kent
2021-06-03 - club - CCH - male - 1244283 - Warwickshire vs Derbyshire
2021-06-03 - club - CCH - male - 1244281 - Worcestershire vs Durham
2021-06-03 - club - CCH - male - 1244280 - Sussex vs Yorkshire
2021-05-27 - club - CCH - male - 1244279 - Middlesex vs Leicestershire
2021-05-27 - club - CCH - male - 1244278 - Surrey vs Gloucestershire
2021-05-27 - club - CCH - male - 1244277 - Sussex vs Northamptonshire
2021-05-27 - club - CCH - male - 1244276 - Yorkshire vs Lancashire
2021-05-27 - club - CCH - male - 1244275 - Worcestershire vs Derbyshire
2021-05-27 - club - CCH - male - 1244274 - Warwickshire vs Nottinghamshire
2021-05-27 - club - CCH - male - 1244273 - Essex vs Durham
2021-05-20 - club - CCH - male - 1244272 - Surrey vs Middlesex
2021-05-20 - club - CCH - male - 1244271 - Somerset vs Gloucestershire
2021-05-20 - club - CCH - male - 1244269 - Kent vs Glamorgan
2021-05-20 - club - CCH - male - 1244268 - Lancashire vs Northamptonshire
2021-05-20 - club - CCH - male - 1244267 - Derbyshire vs Durham
2021-05-20 - club - CCH - male - 1244266 - Warwickshire vs Essex
2021-05-20 - club - CCH - male - 1244265 - Nottinghamshire vs Worcestershire
2021-05-19 - club - CCH - male - 1244270 - Hampshire vs Leicestershire
2021-05-13 - club - CCH - male - 1244264 - Surrey vs Somerset
2021-05-13 - club - CCH - male - 1244263 - Durham vs Worcestershire
2021-05-13 - club - CCH - male - 1244262 - Middlesex vs Hampshire
2021-05-13 - club - CCH - male - 1244261 - Glamorgan vs Yorkshire
2021-05-13 - club - CCH - male - 1244260 - Kent vs Sussex
2021-05-13 - club - CCH - male - 1244259 - Essex vs Derbyshire
2021-05-06 - club - CCH - male - 1244258 - Essex vs Nottinghamshire
2021-05-06 - club - CCH - male - 1244257 - Hampshire vs Somerset
2021-05-06 - club - CCH - male - 1244256 - Sussex vs Northamptonshire
2021-05-06 - club - CCH - male - 1244255 - Glamorgan vs Lancashire
2021-05-06 - club - CCH - male - 1244254 - Middlesex vs Gloucestershire
2021-05-06 - club - CCH - male - 1244253 - Warwickshire vs Worcestershire
2021-05-06 - club - CCH - male - 1244252 - Leicestershire vs Surrey
2021-05-06 - club - CCH - male - 1244251 - Kent vs Yorkshire
2021-04-29 - club - CCH - male - 1244250 - Hampshire vs Surrey
2021-04-29 - club - CCH - male - 1244249 - Yorkshire vs Northamptonshire
2021-04-29 - club - CCH - male - 1244248 - Kent vs Glamorgan
2021-04-29 - club - CCH - male - 1244247 - Middlesex vs Somerset
2021-04-29 - club - CCH - male - 1244246 - Leicestershire vs Gloucestershire
2021-04-29 - club - CCH - male - 1244245 - Warwickshire vs Durham
2021-04-29 - club - CCH - male - 1244244 - Essex vs Worcestershire
2021-04-29 - club - CCH - male - 1244243 - Nottinghamshire vs Derbyshire
2021-04-29 - club - CCH - male - 1244242 - Sussex vs Lancashire
2021-04-22 - club - CCH - male - 1244240 - Glamorgan vs Northamptonshire
2021-04-22 - club - CCH - male - 1244239 - Surrey vs Middlesex
2021-04-22 - club - CCH - male - 1244238 - Essex vs Warwickshire
2021-04-22 - club - CCH - male - 1244237 - Hampshire vs Gloucestershire
2021-04-22 - club - CCH - male - 1244236 - Worcestershire vs Nottinghamshire
2021-04-22 - club - CCH - male - 1244235 - Lancashire vs Kent
2021-04-22 - club - CCH - male - 1244234 - Durham vs Derbyshire
2021-04-22 - club - CCH - male - 1244233 - Yorkshire vs Sussex
2021-04-15 - club - SSH - male - 1244521 - New South Wales vs Queensland
2021-04-15 - club - CCH - male - 1244232 - Leicestershire vs Surrey
2021-04-15 - club - CCH - male - 1244231 - Nottinghamshire vs Warwickshire
2021-04-15 - club - CCH - male - 1244230 - Essex vs Durham
2021-04-15 - club - CCH - male - 1244229 - Derbyshire vs Worcestershire
2021-04-15 - club - CCH - male - 1244228 - Somerset vs Gloucestershire
2021-04-15 - club - CCH - male - 1244227 - Glamorgan vs Sussex
2021-04-15 - club - CCH - male - 1244226 - Yorkshire vs Kent
2021-04-15 - club - CCH - male - 1244225 - Lancashire vs Northamptonshire
2021-04-15 - club - CCH - male - 1244224 - Hampshire vs Middlesex
2021-04-08 - club - CCH - male - 1244223 - Derbyshire vs Warwickshire
2021-04-08 - club - CCH - male - 1244222 - Glamorgan vs Yorkshire
2021-04-08 - club - CCH - male - 1244221 - Durham vs Nottinghamshire
2021-04-08 - club - CCH - male - 1244220 - Surrey vs Gloucestershire
2021-04-08 - club - CCH - male - 1244219 - Hampshire vs Leicestershire
2021-04-08 - club - CCH - male - 1244218 - Middlesex vs Somerset
2021-04-08 - club - CCH - male - 1244217 - Sussex vs Lancashire
2021-04-08 - club - CCH - male - 1244216 - Essex vs Worcestershire
2021-04-08 - club - CCH - male - 1244215 - Kent vs Northamptonshire
2021-04-03 - club - SSH - male - 1251085 - Tasmania vs Western Australia
2021-04-03 - club - SSH - male - 1251084 - South Australia vs Victoria
2021-04-03 - club - SSH - male - 1251083 - New South Wales vs Queensland
2021-04-03 - club - PKS - male - 1234930 - Otago Volts vs Northern Districts
2021-04-03 - club - PKS - male - 1234929 - Central Stags vs Canterbury
2021-04-03 - club - PKS - male - 1234928 - Wellington Firebirds vs Auckland Aces
2021-03-27 - club - PKS - male - 1234927 - Auckland Aces vs Canterbury
2021-03-27 - club - PKS - male - 1234925 - Wellington Firebirds vs Northern Districts
2021-03-26 - club - PKS - male - 1234926 - Otago Volts vs Central Stags
2021-03-20 - club - SSH - male - 1244510 - Tasmania vs New South Wales
2021-03-19 - club - PKS - male - 1234924 - Central Stags vs Canterbury
2021-03-18 - club - PKS - male - 1234923 - Auckland Aces vs Otago Volts
2021-03-18 - club - PKS - male - 1234922 - Northern Districts vs Wellington Firebirds
2021-03-15 - club - SSH - male - 1244504 - Victoria vs Queensland
2021-03-11 - club - PKS - male - 1234921 - Canterbury vs Otago Volts
2021-03-11 - club - PKS - male - 1234920 - Auckland Aces vs Northern Districts
2021-03-11 - club - PKS - male - 1234919 - Central Stags vs Wellington Firebirds
2021-03-06 - club - SSH - male - 1251095 - South Australia vs New South Wales
2021-03-06 - club - SSH - male - 1244505 - Western Australia vs Queensland
2021-03-05 - club - SSH - male - 1244506 - Tasmania vs Victoria
2021-02-17 - club - SSH - male - 1244519 - Tasmania vs Queensland
2021-02-17 - club - SSH - male - 1244512 - New South Wales vs Victoria
2020-11-14 - club - PKS - male - 1234918 - Otago Volts vs Canterbury
2020-11-14 - club - PKS - male - 1234917 - Auckland Aces vs Wellington Firebirds
2020-11-14 - club - PKS - male - 1234916 - Northern Districts vs Central Stags
2020-11-08 - club - SSH - male - 1233453 - Queensland vs South Australia
2020-11-08 - club - SSH - male - 1233452 - New South Wales vs Tasmania
2020-11-05 - club - PKS - male - 1234915 - Canterbury vs Northern Districts
2020-11-05 - club - PKS - male - 1234914 - Otago Volts vs Wellington Firebirds
2020-10-30 - club - SSH - male - 1233450 - South Australia vs Victoria
2020-10-30 - club - SSH - male - 1233449 - Western Australia vs Tasmania
2020-10-30 - club - SSH - male - 1233448 - Queensland vs New South Wales
2020-10-28 - club - PKS - male - 1234912 - Wellington Firebirds vs Canterbury
2020-10-28 - club - PKS - male - 1234911 - Auckland Aces vs Central Stags
2020-10-28 - club - PKS - male - 1234910 - Northern Districts vs Otago Volts
2020-10-20 - club - PKS - male - 1234909 - Otago Volts vs Auckland Aces
2020-10-19 - club - SSH - male - 1233446 - New South Wales vs Western Australia
2020-10-19 - club - SSH - male - 1233445 - South Australia vs Tasmania
2020-10-19 - club - PKS - male - 1234908 - Wellington Firebirds vs Canterbury
2020-10-19 - club - PKS - male - 1234907 - Northern Districts vs Central Stags
2020-10-10 - club - SSH - male - 1233444 - Tasmania vs Queensland
2020-10-10 - club - SSH - male - 1233443 - Western Australia vs South Australia
2020-09-23 - club - BWT - male - 1230247 - Somerset vs Essex
2020-09-06 - club - BWT - male - 1227628 - Sussex vs Surrey
2020-09-06 - club - BWT - male - 1227627 - Hampshire vs Kent
2020-09-06 - club - BWT - male - 1227626 - Middlesex vs Essex
2020-09-06 - club - BWT - male - 1227625 - Leicestershire vs Yorkshire
2020-09-06 - club - BWT - male - 1227624 - Durham vs Nottinghamshire
2020-09-06 - club - BWT - male - 1227623 - Lancashire vs Derbyshire
2020-09-06 - club - BWT - male - 1227622 - Somerset vs Worcestershire
2020-09-06 - club - BWT - male - 1227621 - Gloucestershire vs Northamptonshire
2020-09-06 - club - BWT - male - 1227620 - Warwickshire vs Glamorgan
2020-08-22 - club - BWT - male - 1227619 - Kent vs Surrey
2020-08-22 - club - BWT - male - 1227618 - Sussex vs Middlesex
2020-08-22 - club - BWT - male - 1227617 - Essex vs Hampshire
2020-08-22 - club - BWT - male - 1227616 - Yorkshire vs Lancashire
2020-08-22 - club - BWT - male - 1227615 - Leicestershire vs Nottinghamshire
2020-08-22 - club - BWT - male - 1227614 - Durham vs Derbyshire
2020-08-22 - club - BWT - male - 1227613 - Warwickshire vs Worcestershire
2020-08-22 - club - BWT - male - 1227612 - Somerset vs Gloucestershire
2020-08-22 - club - BWT - male - 1227611 - Glamorgan vs Northamptonshire
2020-08-15 - club - BWT - male - 1227610 - Sussex vs Essex
2020-08-15 - club - BWT - male - 1227609 - Middlesex vs Kent
2020-08-15 - club - BWT - male - 1227608 - Surrey vs Hampshire
2020-08-15 - club - BWT - male - 1227607 - Yorkshire vs Derbyshire
2020-08-15 - club - BWT - male - 1227606 - Nottinghamshire vs Lancashire
2020-08-15 - club - BWT - male - 1227605 - Durham vs Leicestershire
2020-08-15 - club - BWT - male - 1227604 - Warwickshire vs Somerset
2020-08-15 - club - BWT - male - 1227603 - Worcestershire vs Northamptonshire
2020-08-15 - club - BWT - male - 1227602 - Glamorgan vs Gloucestershire
2020-08-08 - club - BWT - male - 1227601 - Middlesex vs Hampshire
2020-08-08 - club - BWT - male - 1227600 - Sussex vs Kent
2020-08-08 - club - BWT - male - 1227599 - Essex vs Surrey
2020-08-08 - club - BWT - male - 1227598 - Yorkshire vs Nottinghamshire
2020-08-08 - club - BWT - male - 1227597 - Leicestershire vs Derbyshire
2020-08-08 - club - BWT - male - 1227596 - Durham vs Lancashire
2020-08-08 - club - BWT - male - 1227595 - Worcestershire vs Glamorgan
2020-08-08 - club - BWT - male - 1227594 - Somerset vs Northamptonshire
2020-08-08 - club - BWT - male - 1227593 - Gloucestershire vs Warwickshire
2020-08-01 - club - BWT - male - 1227592 - Sussex vs Hampshire
2020-08-01 - club - BWT - male - 1227591 - Middlesex vs Surrey
2020-08-01 - club - BWT - male - 1227590 - Kent vs Essex
2020-08-01 - club - BWT - male - 1227589 - Lancashire vs Leicestershire
2020-08-01 - club - BWT - male - 1227588 - Durham vs Yorkshire
2020-08-01 - club - BWT - male - 1227587 - Nottinghamshire vs Derbyshire
2020-08-01 - club - BWT - male - 1227586 - Northamptonshire vs Warwickshire
2020-08-01 - club - BWT - male - 1227585 - Somerset vs Glamorgan
2020-08-01 - club - BWT - male - 1227584 - Gloucestershire vs Worcestershire
2020-03-10 - club - PKS - male - 1197596 - Auckland Aces vs Wellington Firebirds
2020-03-10 - club - PKS - male - 1197595 - Otago Volts vs Central Stags
2020-03-10 - club - PKS - male - 1197594 - Northern Districts vs Canterbury
2020-03-06 - club - SSH - male - 1196140 - Western Australia vs Queensland
2020-03-06 - club - SSH - male - 1196139 - Victoria vs South Australia
2020-03-06 - club - SSH - male - 1196138 - New South Wales vs Tasmania
2020-03-01 - club - PKS - male - 1197593 - Auckland Aces vs Northern Districts
2020-03-01 - club - PKS - male - 1197592 - Otago Volts vs Canterbury
2020-03-01 - club - PKS - male - 1197591 - Wellington Firebirds vs Central Stags
2020-02-24 - club - SSH - male - 1196137 - Victoria vs Queensland
2020-02-24 - club - SSH - male - 1196136 - Western Australia vs Tasmania
2020-02-24 - club - SSH - male - 1196135 - New South Wales vs South Australia
2020-02-22 - club - PKS - male - 1197590 - Central Stags vs Northern Districts
2020-02-22 - club - PKS - male - 1197589 - Canterbury vs Wellington Firebirds
2020-02-22 - club - PKS - male - 1197588 - Auckland Aces vs Otago Volts
2020-02-14 - club - SSH - male - 1196134 - Tasmania vs Queensland
2020-02-14 - club - SSH - male - 1196133 - South Australia vs Western Australia
2020-02-14 - club - SSH - male - 1196132 - Victoria vs New South Wales
2019-12-07 - club - SSH - male - 1196131 - Tasmania vs South Australia
2019-12-07 - club - SSH - male - 1196129 - Western Australia vs Victoria
2019-11-12 - club - SSH - male - 1196125 - Queensland vs Victoria
2019-11-08 - club - PKS - male - 1197587 - Wellington Firebirds vs Auckland Aces
2019-11-08 - club - PKS - male - 1197586 - Central Stags vs Canterbury
2019-11-08 - club - PKS - male - 1197585 - Otago Volts vs Northern Districts
2019-11-02 - club - SSH - male - 1196122 - Western Australia vs Queensland
2019-11-01 - club - SSH - male - 1196121 - New South Wales vs South Australia
2019-10-30 - club - PKS - male - 1197584 - Northern Districts vs Central Stags
2019-10-29 - club - PKS - male - 1197582 - Wellington Firebirds vs Canterbury
2019-10-21 - club - PKS - male - 1197581 - Auckland Aces vs Central Stags
2019-10-21 - club - PKS - male - 1197580 - Canterbury vs Northern Districts
2019-10-21 - club - PKS - male - 1197579 - Wellington Firebirds vs Otago Volts
2019-10-18 - club - SSH - male - 1196119 - Victoria vs Western Australia
2019-10-18 - club - SSH - male - 1196118 - South Australia vs Queensland
2019-10-18 - club - SSH - male - 1196117 - Tasmania vs New South Wales
2019-10-10 - club - SSH - male - 1196115 - Queensland vs New South Wales
2019-10-10 - club - SSH - male - 1196114 - Victoria vs South Australia
2019-09-23 - club - CCH - male - 1167038 - Sussex vs Worcestershire
2019-09-23 - club - CCH - male - 1167037 - Middlesex vs Derbyshire
2019-09-23 - club - CCH - male - 1167036 - Leicestershire vs Lancashire
2019-09-23 - club - CCH - male - 1167035 - Gloucestershire vs Northamptonshire
2019-09-23 - club - CCH - male - 1167034 - Durham vs Glamorgan
2019-09-23 - club - CCH - male - 1166968 - Yorkshire vs Warwickshire
2019-09-23 - club - CCH - male - 1166967 - Surrey vs Nottinghamshire
2019-09-23 - club - CCH - male - 1166966 - Somerset vs Essex
2019-09-23 - club - CCH - male - 1166965 - Kent vs Hampshire
2019-09-16 - club - CCH - male - 1167033 - Worcestershire vs Gloucestershire
2019-09-16 - club - CCH - male - 1167032 - Northamptonshire vs Durham
2019-09-16 - club - CCH - male - 1167031 - Lancashire vs Middlesex
2019-09-16 - club - CCH - male - 1167030 - Glamorgan vs Leicestershire
2019-09-16 - club - CCH - male - 1167029 - Derbyshire vs Sussex
2019-09-16 - club - CCH - male - 1166964 - Kent vs Yorkshire
2019-09-16 - club - CCH - male - 1166962 - Hampshire vs Somerset
2019-09-16 - club - CCH - male - 1166961 - Surrey vs Essex
2019-09-10 - club - CCH - male - 1167028 - Worcestershire vs Glamorgan
2019-09-10 - club - CCH - male - 1167027 - Durham vs Middlesex
2019-09-10 - club - CCH - male - 1167026 - Leicestershire vs Northamptonshire
2019-09-10 - club - CCH - male - 1167025 - Derbyshire vs Lancashire
2019-09-10 - club - CCH - male - 1167024 - Gloucestershire vs Sussex
2019-09-10 - club - CCH - male - 1166960 - Somerset vs Yorkshire
2019-09-10 - club - CCH - male - 1166959 - Kent vs Nottinghamshire
2019-09-10 - club - CCH - male - 1166957 - Warwickshire vs Essex
2019-08-18 - club - CCH - male - 1167023 - Middlesex vs Sussex
2019-08-18 - club - CCH - male - 1167022 - Worcestershire vs Northamptonshire
2019-08-18 - club - CCH - male - 1167021 - Glamorgan vs Lancashire
2019-08-18 - club - CCH - male - 1167020 - Durham vs Leicestershire
2019-08-18 - club - CCH - male - 1167019 - Derbyshire vs Gloucestershire
2019-08-18 - club - CCH - male - 1166956 - Yorkshire vs Nottinghamshire
2019-08-18 - club - CCH - male - 1166955 - Warwickshire vs Somerset
2019-08-18 - club - CCH - male - 1166953 - Kent vs Essex
2019-07-21 - club - CCH - male - 1167018 - Gloucestershire vs Worcestershire
2019-07-15 - club - CCH - male - 1167017 - Leicestershire vs Gloucestershire
2019-07-14 - club - CCH - male - 1167016 - Northamptonshire vs Derbyshire
2019-07-13 - club - CCH - male - 1167015 - Sussex vs Lancashire
2019-07-13 - club - CCH - male - 1167013 - Durham vs Worcestershire
2019-07-13 - club - CCH - male - 1166952 - Yorkshire vs Somerset
2019-07-13 - club - CCH - male - 1166951 - Essex vs Warwickshire
2019-07-13 - club - CCH - male - 1166950 - Surrey vs Nottinghamshire
2019-07-13 - club - CCH - male - 1166949 - Hampshire vs Kent
2019-07-07 - club - CCH - male - 1167012 - Derbyshire vs Worcestershire
2019-07-07 - club - CCH - male - 1167011 - Northamptonshire vs Lancashire
2019-07-07 - club - CCH - male - 1167010 - Middlesex vs Gloucestershire
2019-07-07 - club - CCH - male - 1167009 - Durham vs Leicestershire
2019-07-07 - club - CCH - male - 1166948 - Surrey vs Kent
2019-07-07 - club - CCH - male - 1166947 - Somerset vs Nottinghamshire
2019-07-07 - club - CCH - male - 1166945 - Yorkshire vs Essex
2019-06-30 - club - CCH - male - 1167008 - Northamptonshire vs Sussex
2019-06-30 - club - CCH - male - 1167007 - Lancashire vs Durham
2019-06-30 - club - CCH - male - 1167005 - Derbyshire vs Middlesex
2019-06-30 - club - CCH - male - 1166944 - Yorkshire vs Surrey
2019-06-30 - club - CCH - male - 1166943 - Nottinghamshire vs Essex
2019-06-30 - club - CCH - male - 1166942 - Somerset vs Hampshire
2019-06-30 - club - CCH - male - 1166941 - Kent vs Warwickshire
2019-06-24 - club - CCH - male - 1167004 - Durham vs Sussex
2019-06-24 - club - CCH - male - 1167003 - Northamptonshire vs Leicestershire
2019-06-23 - club - CCH - male - 1167002 - Gloucestershire vs Glamorgan
2019-06-23 - club - CCH - male - 1166940 - Surrey vs Warwickshire
2019-06-23 - club - CCH - male - 1166939 - Essex vs Somerset
2019-06-18 - club - CCH - male - 1167001 - Sussex vs Worcestershire
2019-06-17 - club - CCH - male - 1166999 - Leicestershire vs Gloucestershire
2019-06-17 - club - CCH - male - 1166938 - Yorkshire vs Warwickshire
2019-06-17 - club - CCH - male - 1166937 - Kent vs Nottinghamshire
2019-06-16 - club - CCH - male - 1167000 - Middlesex vs Glamorgan
2019-06-16 - club - CCH - male - 1166936 - Hampshire vs Essex
2019-06-11 - club - CCH - male - 1166997 - Sussex vs Gloucestershire
2019-06-11 - club - CCH - male - 1166994 - Glamorgan vs Derbyshire
2019-06-10 - club - CCH - male - 1166996 - Worcestershire vs Lancashire
2019-06-10 - club - CCH - male - 1166995 - Leicestershire vs Middlesex
2019-06-10 - club - CCH - male - 1166993 - Durham vs Northamptonshire
2019-06-10 - club - CCH - male - 1166935 - Surrey vs Yorkshire
2019-06-09 - club - CCH - male - 1166933 - Nottinghamshire vs Hampshire
2019-06-03 - club - CCH - male - 1166989 - Durham vs Derbyshire
2019-06-03 - club - CCH - male - 1166932 - Yorkshire vs Essex
2019-06-03 - club - CCH - male - 1166931 - Warwickshire vs Nottinghamshire
2019-06-02 - club - CCH - male - 1166991 - Middlesex vs Sussex
2019-05-27 - club - CCH - male - 1166988 - Middlesex vs Worcestershire
2019-05-27 - club - CCH - male - 1166987 - Glamorgan vs Sussex
2019-05-27 - club - CCH - male - 1166985 - Gloucestershire vs Lancashire
2019-05-27 - club - CCH - male - 1166929 - Yorkshire vs Hampshire
2019-05-27 - club - CCH - male - 1166928 - Warwickshire vs Surrey
2019-05-27 - club - CCH - male - 1166927 - Essex vs Kent
2019-05-20 - club - CCH - male - 1166984 - Sussex vs Northamptonshire
2019-05-20 - club - CCH - male - 1166983 - Worcestershire vs Lancashire
2019-05-20 - club - CCH - male - 1166982 - Durham vs Gloucestershire
2019-05-20 - club - CCH - male - 1166926 - Somerset vs Warwickshire
2019-05-20 - club - CCH - male - 1166925 - Surrey vs Kent
2019-05-20 - club - CCH - male - 1166924 - Hampshire vs Nottinghamshire
2019-05-19 - club - CCH - male - 1166981 - Derbyshire vs Glamorgan
2019-05-14 - club - CCH - male - 1166980 - Durham vs Worcestershire
2019-05-14 - club - CCH - male - 1166979 - Middlesex vs Leicestershire
2019-05-14 - club - CCH - male - 1166978 - Northamptonshire vs Lancashire
2019-05-14 - club - CCH - male - 1166977 - Gloucestershire vs Glamorgan
2019-05-14 - club - CCH - male - 1166923 - Hampshire vs Warwickshire
2019-05-14 - club - CCH - male - 1166922 - Surrey vs Somerset
2019-05-14 - club - CCH - male - 1166921 - Yorkshire vs Kent
2019-05-14 - club - CCH - male - 1166920 - Nottinghamshire vs Essex
2019-04-11 - club - CCH - male - 1166976 - Middlesex vs Lancashire
2019-04-11 - club - CCH - male - 1166975 - Worcestershire vs Leicestershire
2019-04-11 - club - CCH - male - 1166974 - Derbyshire vs Gloucestershire
2019-04-11 - club - CCH - male - 1166973 - Glamorgan vs Northamptonshire
2019-04-11 - club - CCH - male - 1166972 - Durham vs Sussex
2019-04-11 - club - CCH - male - 1166919 - Kent vs Warwickshire
2019-04-11 - club - CCH - male - 1166918 - Surrey vs Essex
2019-04-11 - club - CCH - male - 1166917 - Nottinghamshire vs Somerset
2019-04-11 - club - CCH - male - 1166916 - Yorkshire vs Hampshire
2019-04-05 - club - CCH - male - 1166971 - Sussex vs Leicestershire
2019-04-05 - club - CCH - male - 1166970 - Northamptonshire vs Middlesex
2019-04-05 - club - CCH - male - 1166969 - Derbyshire vs Durham
2019-04-05 - club - CCH - male - 1166915 - Somerset vs Kent
2019-04-05 - club - CCH - male - 1166914 - Nottinghamshire vs Yorkshire
2019-04-05 - club - CCH - male - 1166913 - Hampshire vs Essex
2019-03-20 - club - SSH - male - 1150137 - Western Australia vs Queensland
2019-03-20 - club - SSH - male - 1150136 - South Australia vs Victoria
2019-03-20 - club - SSH - male - 1150135 - New South Wales vs Tasmania
2019-03-17 - club - PKS - male - 1160302 - Otago Volts vs Auckland Aces
2019-03-17 - club - PKS - male - 1160301 - Northern Districts vs Central Stags
2019-03-12 - club - SSH - male - 1150134 - Western Australia vs Tasmania
2019-03-09 - club - PKS - male - 1160300 - Otago Volts vs Wellington Firebirds
2019-03-09 - club - PKS - male - 1160299 - Central Stags vs Northern Districts
2019-03-09 - club - PKS - male - 1160298 - Canterbury vs Auckland Aces
2019-03-05 - club - SSH - male - 1150129 - Victoria vs Tasmania
2019-03-03 - club - SSH - male - 1150131 - South Australia vs Western Australia
2019-03-03 - club - SSH - male - 1150130 - New South Wales vs Queensland
2019-03-01 - club - PKS - male - 1160297 - Northern Districts vs Auckland Aces
2019-03-01 - club - PKS - male - 1160296 - Central Stags vs Otago Volts
2019-03-01 - club - PKS - male - 1160295 - Canterbury vs Wellington Firebirds
2019-02-23 - club - SSH - male - 1150128 - South Australia vs Tasmania
2019-02-23 - club - SSH - male - 1150126 - Queensland vs Victoria
2019-02-21 - club - PKS - male - 1160294 - Wellington Firebirds vs Northern Districts
2019-02-21 - club - PKS - male - 1160293 - Canterbury vs Central Stags
2019-02-21 - club - PKS - male - 1160292 - Auckland Aces vs Otago Volts
2018-12-14 - club - PKS - male - 1160291 - Otago Volts vs Canterbury
2018-12-14 - club - PKS - male - 1160290 - Central Stags vs Wellington Firebirds
2018-12-14 - club - PKS - male - 1160289 - Auckland Aces vs Northern Districts
2018-12-06 - club - PKS - male - 1160288 - Otago Volts vs Central Stags
2018-12-06 - club - PKS - male - 1160287 - Northern Districts vs Wellington Firebirds
2018-12-06 - club - PKS - male - 1160286 - Auckland Aces vs Canterbury
2018-11-27 - club - SSH - male - 1150121 - Victoria vs Queensland
2018-11-17 - club - SSH - male - 1150119 - Tasmania vs Victoria
2018-11-16 - club - SSH - male - 1150118 - South Australia vs Western Australia
2018-11-05 - club - SSH - male - 1150114 - New South Wales vs Tasmania
2018-10-17 - club - PKS - male - 1160285 - Wellington Firebirds vs Otago Volts
2018-10-17 - club - PKS - male - 1160284 - Canterbury vs Northern Districts
2018-10-17 - club - PKS - male - 1160283 - Auckland Aces vs Central Stags
2018-10-16 - club - SSH - male - 1150109 - Tasmania vs Queensland
2018-10-16 - club - SSH - male - 1150108 - New South Wales vs South Australia
2018-10-10 - club - PKS - male - 1160282 - Wellington Firebirds vs Auckland Aces
2018-10-10 - club - PKS - male - 1160281 - Northern Districts vs Otago Volts
2018-10-10 - club - PKS - male - 1160280 - Central Stags vs Canterbury
2018-09-24 - club - CCH - male - 1127741 - Derbyshire vs Gloucestershire
2018-09-24 - club - CCH - male - 1127740 - Glamorgan vs Leicestershire
2018-09-24 - club - CCH - male - 1127739 - Sussex vs Northamptonshire
2018-09-24 - club - CCH - male - 1127737 - Kent vs Warwickshire
2018-09-24 - club - CCH - male - 1127671 - Somerset vs Nottinghamshire
2018-09-24 - club - CCH - male - 1127670 - Worcestershire vs Yorkshire
2018-09-18 - club - CCH - male - 1127736 - Leicestershire vs Durham
2018-09-18 - club - CCH - male - 1127735 - Gloucestershire vs Northamptonshire
2018-09-18 - club - CCH - male - 1127734 - Warwickshire vs Sussex
2018-09-18 - club - CCH - male - 1127733 - Middlesex vs Derbyshire
2018-09-18 - club - CCH - male - 1127667 - Surrey vs Somerset
2018-09-18 - club - CCH - male - 1127666 - Yorkshire vs Hampshire
2018-09-18 - club - CCH - male - 1127665 - Worcestershire vs Essex
2018-09-10 - club - CCH - male - 1127731 - Leicestershire vs Warwickshire
2018-09-10 - club - CCH - male - 1127730 - Glamorgan vs Gloucestershire
2018-09-10 - club - CCH - male - 1127729 - Northamptonshire vs Derbyshire
2018-09-10 - club - CCH - male - 1127728 - Middlesex vs Kent
2018-09-10 - club - CCH - male - 1127727 - Durham vs Sussex
2018-09-10 - club - CCH - male - 1127664 - Nottinghamshire vs Essex
2018-09-10 - club - CCH - male - 1127663 - Worcestershire vs Surrey
2018-09-10 - club - CCH - male - 1127662 - Yorkshire vs Lancashire
2018-09-10 - club - CCH - male - 1127661 - Somerset vs Hampshire
2018-09-04 - club - CCH - male - 1127726 - Gloucestershire vs Middlesex
2018-09-04 - club - CCH - male - 1127725 - Derbyshire vs Glamorgan
2018-09-04 - club - CCH - male - 1127724 - Sussex vs Leicestershire
2018-09-04 - club - CCH - male - 1127723 - Warwickshire vs Durham
2018-09-04 - club - CCH - male - 1127722 - Kent vs Northamptonshire
2018-09-04 - club - CCH - male - 1127660 - Nottinghamshire vs Yorkshire
2018-09-04 - club - CCH - male - 1127659 - Lancashire vs Somerset
2018-09-04 - club - CCH - male - 1127658 - Hampshire vs Worcestershire
2018-09-04 - club - CCH - male - 1127657 - Surrey vs Essex
2018-08-29 - club - CCH - male - 1127721 - Gloucestershire vs Leicestershire
2018-08-29 - club - CCH - male - 1127719 - Middlesex vs Sussex
2018-08-29 - club - CCH - male - 1127718 - Durham vs Northamptonshire
2018-08-29 - club - CCH - male - 1127717 - Glamorgan vs Warwickshire
2018-08-29 - club - CCH - male - 1127656 - Worcestershire vs Lancashire
2018-08-29 - club - CCH - male - 1127654 - Somerset vs Yorkshire
2018-08-29 - club - CCH - male - 1127653 - Essex vs Hampshire
2018-08-19 - club - CCH - male - 1127714 - Glamorgan vs Durham
2018-08-19 - club - CCH - male - 1127713 - Northamptonshire vs Middlesex
2018-08-19 - club - CCH - male - 1127712 - Gloucestershire vs Warwickshire
2018-08-19 - club - CCH - male - 1127652 - Somerset vs Essex
2018-08-19 - club - CCH - male - 1127651 - Yorkshire vs Worcestershire
2018-08-19 - club - CCH - male - 1127650 - Surrey vs Lancashire
2018-08-19 - club - CCH - male - 1127649 - Hampshire vs Nottinghamshire
2018-07-22 - club - CCH - male - 1127711 - Sussex vs Glamorgan
2018-07-22 - club - CCH - male - 1127710 - Middlesex vs Warwickshire
2018-07-22 - club - CCH - male - 1127709 - Derbyshire vs Northamptonshire
2018-07-22 - club - CCH - male - 1127708 - Gloucestershire vs Durham
2018-07-22 - club - CCH - male - 1127707 - Kent vs Leicestershire
2018-07-22 - club - CCH - male - 1127648 - Nottinghamshire vs Surrey
2018-07-22 - club - CCH - male - 1127647 - Somerset vs Worcestershire
2018-07-22 - club - CCH - male - 1127646 - Yorkshire vs Lancashire
2018-07-16 - club - CCH - male - 1127706 - Sussex vs Gloucestershire
2018-06-25 - club - CCH - male - 1127705 - Derbyshire vs Leicestershire
2018-06-25 - club - CCH - male - 1127704 - Northamptonshire vs Glamorgan
2018-06-25 - club - CCH - male - 1127703 - Warwickshire vs Durham
2018-06-25 - club - CCH - male - 1127702 - Kent vs Middlesex
2018-06-25 - club - CCH - male - 1127645 - Nottinghamshire vs Worcestershire
2018-06-25 - club - CCH - male - 1127644 - Yorkshire vs Surrey
2018-06-25 - club - CCH - male - 1127643 - Hampshire vs Lancashire
2018-06-25 - club - CCH - male - 1127642 - Essex vs Somerset
2018-06-20 - club - CCH - male - 1127701 - Leicestershire vs Middlesex
2018-06-20 - club - CCH - male - 1127700 - Kent vs Warwickshire
2018-06-20 - club - CCH - male - 1127698 - Northamptonshire vs Gloucestershire
2018-06-20 - club - CCH - male - 1127697 - Sussex vs Durham
2018-06-20 - club - CCH - male - 1127640 - Surrey vs Somerset
2018-06-20 - club - CCH - male - 1127639 - Nottinghamshire vs Essex
2018-06-20 - club - CCH - male - 1127638 - Yorkshire vs Hampshire
2018-06-09 - club - CCH - male - 1127696 - Kent vs Gloucestershire
2018-06-09 - club - CCH - male - 1127694 - Durham vs Derbyshire
2018-06-09 - club - CCH - male - 1127693 - Glamorgan vs Warwickshire
2018-06-09 - club - CCH - male - 1127637 - Somerset vs Nottinghamshire
2018-06-09 - club - CCH - male - 1127636 - Lancashire vs Essex
2018-06-09 - club - CCH - male - 1127635 - Surrey vs Hampshire
2018-05-11 - club - CCH - male - 1127691 - Derbyshire vs Durham
2018-05-11 - club - CCH - male - 1127689 - Northamptonshire vs Warwickshire
2018-05-11 - club - CCH - male - 1127688 - Kent vs Sussex
2018-05-11 - club - CCH - male - 1127634 - Nottinghamshire vs Lancashire
2018-05-11 - club - CCH - male - 1127633 - Hampshire vs Somerset
2018-05-11 - club - CCH - male - 1127632 - Essex vs Worcestershire
2018-05-11 - club - CCH - male - 1127631 - Surrey vs Yorkshire
2018-05-04 - club - CCH - male - 1127687 - Middlesex vs Sussex
2018-05-04 - club - CCH - male - 1127686 - Glamorgan vs Kent
2018-05-04 - club - CCH - male - 1127685 - Leicestershire vs Durham
2018-05-04 - club - CCH - male - 1127630 - Nottinghamshire vs Hampshire
2018-05-04 - club - CCH - male - 1127629 - Surrey vs Worcestershire
2018-05-04 - club - CCH - male - 1127628 - Somerset vs Lancashire
2018-05-04 - club - CCH - male - 1127627 - Yorkshire vs Essex
2018-05-03 - club - CCH - male - 1127684 - Derbyshire vs Warwickshire
2018-04-27 - club - CCH - male - 1127683 - Leicestershire vs Derbyshire
2018-04-27 - club - CCH - male - 1127682 - Sussex vs Gloucestershire
2018-04-27 - club - CCH - male - 1127680 - Middlesex vs Glamorgan
2018-04-27 - club - CCH - male - 1127626 - Somerset vs Yorkshire
2018-04-27 - club - CCH - male - 1127625 - Worcestershire vs Nottinghamshire
2018-04-27 - club - CCH - male - 1127624 - Lancashire vs Surrey
2018-04-27 - club - CCH - male - 1127623 - Hampshire vs Essex
2018-04-20 - club - CCH - male - 1127679 - Sussex vs Leicestershire
2018-04-20 - club - CCH - male - 1127678 - Gloucestershire vs Glamorgan
2018-04-20 - club - CCH - male - 1127677 - Derbyshire vs Middlesex
2018-04-20 - club - CCH - male - 1127676 - Northamptonshire vs Warwickshire
2018-04-20 - club - CCH - male - 1127675 - Durham vs Kent
2018-04-20 - club - CCH - male - 1127622 - Somerset vs Worcestershire
2018-04-20 - club - CCH - male - 1127621 - Surrey vs Hampshire
2018-04-20 - club - CCH - male - 1127620 - Yorkshire vs Nottinghamshire
2018-04-20 - club - CCH - male - 1127619 - Essex vs Lancashire
2018-04-13 - club - CCH - male - 1127674 - Middlesex vs Northamptonshire
2018-04-13 - club - CCH - male - 1127673 - Warwickshire vs Sussex
2018-04-13 - club - CCH - male - 1127672 - Kent vs Gloucestershire
2018-04-13 - club - CCH - male - 1127618 - Lancashire vs Nottinghamshire
2018-04-13 - club - CCH - male - 1127616 - Hampshire vs Worcestershire
2018-04-02 - club - PKS - male - 1120137 - Auckland Aces vs Wellington Firebirds
2018-04-02 - club - PKS - male - 1120136 - Otago Volts vs Canterbury
2018-04-02 - club - PKS - male - 1120135 - Central Stags vs Northern Districts
2018-03-25 - club - PKS - male - 1120134 - Otago Volts vs Auckland Aces
2018-03-25 - club - PKS - male - 1120133 - Wellington Firebirds vs Northern Districts
2018-03-25 - club - PKS - male - 1120132 - Central Stags vs Canterbury
2018-03-23 - club - SSH - male - 1118894 - Tasmania vs Queensland
2018-03-17 - club - PKS - male - 1120131 - Wellington Firebirds vs Central Stags
2018-03-17 - club - PKS - male - 1120130 - Northern Districts vs Otago Volts
2018-03-17 - club - PKS - male - 1120129 - Canterbury vs Auckland Aces
2018-03-14 - club - SSH - male - 1118893 - Western Australia vs South Australia
2018-03-10 - club - PKS - male - 1120128 - Otago Volts vs Wellington Firebirds
2018-03-09 - club - PKS - male - 1120127 - Auckland Aces vs Central Stags
2018-03-09 - club - PKS - male - 1120126 - Northern Districts vs Canterbury
2018-03-01 - club - PKS - male - 1120125 - Central Stags vs Otago Volts
2018-03-01 - club - PKS - male - 1120124 - Canterbury vs Wellington Firebirds
2018-03-01 - club - PKS - male - 1120123 - Auckland Aces vs Northern Districts
2018-02-25 - club - SSH - male - 1118887 - Queensland vs South Australia
2018-02-24 - club - SSH - male - 1118885 - New South Wales vs Tasmania
2018-02-16 - club - SSH - male - 1118882 - Tasmania vs Western Australia
2018-02-08 - club - SSH - male - 1118881 - New South Wales vs Western Australia
2017-12-03 - club - SSH - male - 1118878 - South Australia vs Queensland
2017-11-29 - international - MDM - male - 1125471 - Ireland vs Scotland
2017-11-24 - club - PKS - male - 1120122 - Otago Volts vs Northern Districts
2017-11-24 - club - PKS - male - 1120121 - Auckland Aces vs Canterbury
2017-11-24 - club - PKS - male - 1120120 - Central Stags vs Wellington Firebirds
2017-11-15 - club - PKS - male - 1120119 - Northern Districts vs Auckland Aces
2017-11-15 - club - PKS - male - 1120118 - Otago Volts vs Central Stags
2017-11-15 - club - PKS - male - 1120117 - Wellington Firebirds vs Canterbury
2017-11-13 - club - SSH - male - 1118871 - Queensland vs New South Wales
2017-11-13 - club - SSH - male - 1118870 - Tasmania vs Victoria
2017-11-07 - club - PKS - male - 1120116 - Auckland Aces vs Otago Volts
2017-11-07 - club - PKS - male - 1120115 - Northern Districts vs Wellington Firebirds
2017-11-07 - club - PKS - male - 1120114 - Canterbury vs Central Stags
2017-10-30 - club - PKS - male - 1120113 - Wellington Firebirds vs Otago Volts
2017-10-30 - club - PKS - male - 1120112 - Canterbury vs Northern Districts
2017-10-30 - club - PKS - male - 1120111 - Central Stags vs Auckland Aces
2017-10-27 - club - SSH - male - 1118866 - South Australia vs New South Wales
2017-10-23 - club - PKS - male - 1120110 - Canterbury vs Otago Volts
2017-10-23 - club - PKS - male - 1120109 - Northern Districts vs Central Stags
2017-10-23 - club - PKS - male - 1120108 - Wellington Firebirds vs Auckland Aces
2017-09-25 - club - CCH - male - 1068653 - Derbyshire vs Gloucestershire
2017-09-25 - club - CCH - male - 1068652 - Kent vs Glamorgan
2017-09-25 - club - CCH - male - 1068651 - Leicestershire vs Northamptonshire
2017-09-25 - club - CCH - male - 1068650 - Sussex vs Nottinghamshire
2017-09-25 - club - CCH - male - 1068649 - Worcestershire vs Durham
2017-09-25 - club - CCH - male - 1068583 - Warwickshire vs Hampshire
2017-09-25 - club - CCH - male - 1068582 - Essex vs Yorkshire
2017-09-25 - club - CCH - male - 1068581 - Somerset vs Middlesex
2017-09-25 - club - CCH - male - 1068580 - Surrey vs Lancashire
2017-09-19 - club - CCH - male - 1068648 - Northamptonshire vs Nottinghamshire
2017-09-19 - club - CCH - male - 1068647 - Glamorgan vs Gloucestershire
2017-09-19 - club - CCH - male - 1068646 - Sussex vs Durham
2017-09-19 - club - CCH - male - 1068579 - Hampshire vs Essex
2017-09-19 - club - CCH - male - 1068578 - Middlesex vs Lancashire
2017-09-19 - club - CCH - male - 1068576 - Warwickshire vs Yorkshire
2017-09-16 - international - MDM - male - 1105001 - United Arab Emirates vs Namibia
2017-09-12 - club - CCH - male - 1068644 - Gloucestershire vs Kent
2017-09-12 - club - CCH - male - 1068643 - Glamorgan vs Northamptonshire
2017-09-12 - club - CCH - male - 1068642 - Derbyshire vs Sussex
2017-09-12 - club - CCH - male - 1068641 - Leicestershire vs Worcestershire
2017-09-12 - club - CCH - male - 1068575 - Middlesex vs Hampshire
2017-09-12 - club - CCH - male - 1068574 - Somerset vs Lancashire
2017-09-12 - club - CCH - male - 1068573 - Surrey vs Yorkshire
2017-09-12 - club - CCH - male - 1068572 - Warwickshire vs Essex
2017-09-05 - club - CCH - male - 1068640 - Durham vs Kent
2017-09-05 - club - CCH - male - 1068639 - Derbyshire vs Glamorgan
2017-09-05 - club - CCH - male - 1068638 - Leicestershire vs Gloucestershire
2017-09-05 - club - CCH - male - 1068637 - Nottinghamshire vs Worcestershire
2017-09-05 - club - CCH - male - 1068636 - Northamptonshire vs Sussex
2017-09-05 - club - CCH - male - 1068571 - Somerset vs Warwickshire
2017-09-05 - club - CCH - male - 1068570 - Lancashire vs Essex
2017-09-05 - club - CCH - male - 1068569 - Yorkshire vs Middlesex
2017-09-05 - club - CCH - male - 1068568 - Surrey vs Hampshire
2017-08-28 - club - CCH - male - 1068635 - Durham vs Derbyshire
2017-08-28 - club - CCH - male - 1068634 - Worcestershire vs Gloucestershire
2017-08-28 - club - CCH - male - 1068633 - Leicestershire vs Kent
2017-08-28 - club - CCH - male - 1068632 - Nottinghamshire vs Northamptonshire
2017-08-28 - club - CCH - male - 1068631 - Glamorgan vs Sussex
2017-08-28 - club - CCH - male - 1068567 - Essex vs Somerset
2017-08-28 - club - CCH - male - 1068566 - Warwickshire vs Lancashire
2017-08-28 - club - CCH - male - 1068565 - Middlesex vs Surrey
2017-08-15 - international - MDM - male - 1105000 - Ireland vs Netherlands
2017-08-07 - club - CCH - male - 1068564 - Somerset vs Surrey
2017-08-06 - club - CCH - male - 1068630 - Sussex vs Worcestershire
2017-08-06 - club - CCH - male - 1068629 - Derbyshire vs Nottinghamshire
2017-08-06 - club - CCH - male - 1068628 - Durham vs Leicestershire
2017-08-06 - club - CCH - male - 1068627 - Northamptonshire vs Gloucestershire
2017-08-06 - club - CCH - male - 1068563 - Lancashire vs Hampshire
2017-08-06 - club - CCH - male - 1068562 - Warwickshire vs Middlesex
2017-08-06 - club - CCH - male - 1068561 - Yorkshire vs Essex
2017-07-09 - club - CCH - male - 1068626 - Gloucestershire vs Worcestershire
2017-07-03 - club - CCH - male - 1068624 - Kent vs Northamptonshire
2017-07-03 - club - CCH - male - 1068623 - Glamorgan vs Gloucestershire
2017-07-03 - club - CCH - male - 1068622 - Derbyshire vs Durham
2017-07-03 - club - CCH - male - 1068560 - Hampshire vs Surrey
2017-07-03 - club - CCH - male - 1068559 - Somerset vs Yorkshire
2017-07-03 - club - CCH - male - 1068558 - Warwickshire vs Middlesex
2017-06-26 - club - CCH - male - 1068621 - Sussex vs Gloucestershire
2017-06-26 - club - CCH - male - 1068620 - Kent vs Nottinghamshire
2017-06-26 - club - CCH - male - 1068619 - Northamptonshire vs Leicestershire
2017-06-26 - club - CCH - male - 1068618 - Derbyshire vs Glamorgan
2017-06-26 - club - CCH - male - 1068617 - Durham vs Worcestershire
2017-06-26 - club - CCH - male - 1068557 - Surrey vs Yorkshire
2017-06-26 - club - CCH - male - 1068556 - Lancashire vs Warwickshire
2017-06-26 - club - CCH - male - 1068555 - Hampshire vs Somerset
2017-06-26 - club - CCH - male - 1068554 - Middlesex vs Essex
2017-06-19 - club - CCH - male - 1068616 - Kent vs Worcestershire
2017-06-19 - club - CCH - male - 1068615 - Nottinghamshire vs Leicestershire
2017-06-19 - club - CCH - male - 1068614 - Glamorgan vs Durham
2017-06-19 - club - CCH - male - 1068553 - Essex vs Warwickshire
2017-06-19 - club - CCH - male - 1068552 - Middlesex vs Yorkshire
2017-06-19 - club - CCH - male - 1068551 - Hampshire vs Lancashire
2017-06-09 - club - CCH - male - 1068613 - Leicestershire vs Sussex
2017-06-09 - club - CCH - male - 1068612 - Gloucestershire vs Nottinghamshire
2017-06-09 - club - CCH - male - 1068611 - Worcestershire vs Glamorgan
2017-06-09 - club - CCH - male - 1068610 - Northamptonshire vs Derbyshire
2017-06-09 - club - CCH - male - 1068550 - Surrey vs Essex
2017-06-09 - club - CCH - male - 1068549 - Middlesex vs Lancashire
2017-06-08 - club - CCH - male - 1068609 - Durham vs Kent
2017-06-02 - club - CCH - male - 1068608 - Sussex vs Worcestershire
2017-06-02 - club - CCH - male - 1068607 - Durham vs Northamptonshire
2017-06-02 - club - CCH - male - 1068606 - Nottinghamshire vs Derbyshire
2017-06-02 - club - CCH - male - 1068547 - Lancashire vs Yorkshire
2017-06-02 - club - CCH - male - 1068546 - Hampshire vs Warwickshire
2017-06-02 - club - CCH - male - 1068545 - Somerset vs Middlesex
2017-05-26 - club - CCH - male - 1068604 - Durham vs Glamorgan
2017-05-26 - club - CCH - male - 1068602 - Nottinghamshire vs Gloucestershire
2017-05-26 - club - CCH - male - 1068544 - Surrey vs Essex
2017-05-21 - club - CCH - male - 1068600 - Durham vs Sussex
2017-05-19 - club - CCH - male - 1068597 - Nottinghamshire vs Glamorgan
2017-05-19 - club - CCH - male - 1068541 - Essex vs Hampshire
2017-05-19 - club - CCH - male - 1068540 - Yorkshire vs Lancashire
2017-05-19 - club - CCH - male - 1068539 - Surrey vs Middlesex
2017-04-21 - club - CCH - male - 1068596 - Gloucestershire vs Durham
2017-04-21 - club - CCH - male - 1068594 - Leicestershire vs Glamorgan
2017-04-21 - club - CCH - male - 1068593 - Nottinghamshire vs Sussex
2017-04-21 - club - CCH - male - 1068592 - Worcestershire vs Northamptonshire
2017-04-21 - club - CCH - male - 1068538 - Warwickshire vs Surrey
2017-04-21 - club - CCH - male - 1068537 - Hampshire vs Yorkshire
2017-04-21 - club - CCH - male - 1068536 - Middlesex vs Essex
2017-04-21 - club - CCH - male - 1068535 - Lancashire vs Somerset
2017-04-14 - club - CCH - male - 1068591 - Gloucestershire vs Leicestershire
2017-04-14 - club - CCH - male - 1068590 - Derbyshire vs Northamptonshire
2017-04-14 - club - CCH - male - 1068589 - Glamorgan vs Worcestershire
2017-04-14 - club - CCH - male - 1068588 - Kent vs Sussex
2017-04-14 - club - CCH - male - 1068534 - Warwickshire vs Yorkshire
2017-04-14 - club - CCH - male - 1068533 - Middlesex vs Hampshire
2017-04-14 - club - CCH - male - 1068532 - Somerset vs Essex
2017-04-07 - club - CCH - male - 1068586 - Leicestershire vs Nottinghamshire
2017-04-07 - club - CCH - male - 1068585 - Kent vs Gloucestershire
2017-04-07 - club - CCH - male - 1068584 - Glamorgan vs Northamptonshire
2017-04-07 - club - CCH - male - 1068530 - Lancashire vs Essex
2017-04-07 - club - CCH - male - 1068529 - Surrey vs Warwickshire
2017-04-07 - club - CCH - male - 1068528 - Yorkshire vs Hampshire
2017-03-29 - club - PKS - male - 1051871 - Otago Volts vs Northern Districts
2017-03-29 - club - PKS - male - 1051869 - Canterbury vs Wellington Firebirds
2017-03-26 - club - SSH - male - 1036431 - Victoria vs South Australia
2017-03-21 - club - PKS - male - 1051865 - Central Stags vs Canterbury
2017-03-21 - club - PKS - male - 1051863 - Northern Districts vs Wellington Firebirds
2017-03-21 - club - PKS - male - 1051861 - Otago Volts vs Auckland Aces
2017-03-14 - club - PKS - male - 1051859 - Canterbury vs Otago Volts
2017-03-14 - club - PKS - male - 1051857 - Auckland Aces vs Northern Districts
2017-03-06 - club - PKS - male - 1051853 - Wellington Firebirds vs Otago Volts
2017-03-06 - club - PKS - male - 1051851 - Northern Districts vs Central Stags
2017-03-06 - club - PKS - male - 1051849 - Auckland Aces vs Canterbury
2017-02-25 - club - PKS - male - 1051845 - Northern Districts vs Otago Volts
2017-02-25 - club - PKS - male - 1051843 - Auckland Aces vs Central Stags
2017-02-10 - international - MDM - male - 1068730 - Hong Kong vs Netherlands
2016-11-22 - club - PKS - male - 1051841 - Canterbury vs Auckland Aces
2016-11-22 - club - PKS - male - 1051839 - Central Stags vs Northern Districts
2016-11-22 - club - PKS - male - 1051837 - Otago Volts vs Wellington Firebirds
2016-11-14 - club - PKS - male - 1051831 - Northern Districts vs Auckland Aces
2016-11-05 - club - PKS - male - 1051829 - Otago Volts vs Central Stags
2016-11-05 - club - PKS - male - 1051827 - Auckland Aces vs Wellington Firebirds
2016-11-05 - club - PKS - male - 1051825 - Northern Districts vs Canterbury
2016-10-29 - club - PKS - male - 1051823 - Auckland Aces vs Otago Volts
2016-10-29 - club - PKS - male - 1051821 - Canterbury vs Central Stags
2016-10-29 - club - PKS - male - 1051819 - Wellington Firebirds vs Northern Districts
2016-10-22 - club - PKS - male - 1051817 - Wellington Firebirds vs Auckland Aces
2016-10-22 - club - PKS - male - 1051815 - Canterbury vs Northern Districts
2016-10-22 - club - PKS - male - 1051813 - Central Stags vs Otago Volts
2016-10-16 - international - MDM - male - 1004251 - Papua New Guinea vs Namibia
2016-09-20 - club - CCH - male - 947089 - Gloucestershire vs Sussex
2016-09-20 - club - CCH - male - 947085 - Kent vs Essex
2016-09-20 - club - CCH - male - 946945 - Middlesex vs Yorkshire
2016-09-20 - club - CCH - male - 946943 - Somerset vs Nottinghamshire
2016-09-20 - club - CCH - male - 946941 - Warwickshire vs Lancashire
2016-09-12 - club - CCH - male - 947081 - Worcestershire vs Sussex
2016-09-12 - club - CCH - male - 947079 - Derbyshire vs Leicestershire
2016-09-12 - club - CCH - male - 947077 - Northamptonshire vs Gloucestershire
2016-09-12 - club - CCH - male - 947075 - Glamorgan vs Essex
2016-09-12 - club - CCH - male - 946937 - Durham vs Surrey
2016-09-12 - club - CCH - male - 946935 - Yorkshire vs Somerset
2016-09-12 - club - CCH - male - 946933 - Middlesex vs Lancashire
2016-09-06 - club - CCH - male - 947073 - Leicestershire vs Sussex
2016-09-06 - club - CCH - male - 947071 - Kent vs Northamptonshire
2016-09-06 - club - CCH - male - 947069 - Glamorgan vs Gloucestershire
2016-09-06 - club - CCH - male - 946931 - Somerset vs Warwickshire
2016-09-06 - club - CCH - male - 946929 - Nottinghamshire vs Middlesex
2016-09-06 - club - CCH - male - 946927 - Surrey vs Hampshire
2016-09-06 - club - CCH - male - 946925 - Yorkshire vs Durham
2016-08-31 - club - CCH - male - 947067 - Worcestershire vs Essex
2016-08-31 - club - CCH - male - 947065 - Sussex vs Kent
2016-08-31 - club - CCH - male - 947063 - Derbyshire vs Gloucestershire
2016-08-31 - club - CCH - male - 947061 - Northamptonshire vs Glamorgan
2016-08-31 - club - CCH - male - 946923 - Yorkshire vs Hampshire
2016-08-31 - club - CCH - male - 946921 - Somerset vs Lancashire
2016-08-31 - club - CCH - male - 946919 - Durham vs Nottinghamshire
2016-08-31 - club - CCH - male - 946917 - Middlesex vs Warwickshire
2016-08-23 - club - CCH - male - 947059 - Glamorgan vs Sussex
2016-08-23 - club - CCH - male - 947057 - Northamptonshire vs Worcestershire
2016-08-23 - club - CCH - male - 947055 - Gloucestershire vs Kent
2016-08-23 - club - CCH - male - 947053 - Leicestershire vs Essex
2016-08-23 - club - CCH - male - 946915 - Durham vs Warwickshire
2016-08-23 - club - CCH - male - 946913 - Yorkshire vs Nottinghamshire
2016-08-23 - club - CCH - male - 946911 - Lancashire vs Surrey
2016-08-23 - club - CCH - male - 946909 - Hampshire vs Somerset
2016-08-13 - club - CCH - male - 947051 - Leicestershire vs Northamptonshire
2016-08-13 - club - CCH - male - 947049 - Gloucestershire vs Sussex
2016-08-13 - club - CCH - male - 947047 - Worcestershire vs Glamorgan
2016-08-13 - club - CCH - male - 947045 - Essex vs Derbyshire
2016-08-13 - club - CCH - male - 946907 - Lancashire vs Yorkshire
2016-08-13 - club - CCH - male - 946905 - Surrey vs Warwickshire
2016-08-13 - club - CCH - male - 946903 - Hampshire vs Nottinghamshire
2016-08-13 - club - CCH - male - 946901 - Durham vs Middlesex
2016-08-09 - international - MDM - male - 997991 - United Arab Emirates vs Scotland
2016-08-04 - club - CCH - male - 947041 - Leicestershire vs Derbyshire
2016-08-04 - club - CCH - male - 946899 - Yorkshire vs Warwickshire
2016-08-04 - club - CCH - male - 946897 - Surrey vs Middlesex
2016-08-04 - club - CCH - male - 946895 - Hampshire vs Lancashire
2016-08-04 - club - CCH - male - 946893 - Somerset vs Durham
2016-08-03 - club - CCH - male - 947037 - Worcestershire vs Kent
2016-07-20 - club - CCH - male - 947035 - Gloucestershire vs Leicestershire
2016-07-17 - club - CCH - male - 947033 - Kent vs Sussex
2016-07-17 - club - CCH - male - 947031 - Glamorgan vs Derbyshire
2016-07-17 - club - CCH - male - 946891 - Surrey vs Hampshire
2016-07-17 - club - CCH - male - 946889 - Nottinghamshire vs Somerset
2016-07-16 - club - CCH - male - 946887 - Lancashire vs Durham
2016-07-11 - club - CCH - male - 946885 - Surrey vs Yorkshire
2016-07-10 - club - CCH - male - 947027 - Worcestershire vs Northamptonshire
2016-07-10 - club - CCH - male - 946883 - Somerset vs Middlesex
2016-07-10 - club - CCH - male - 946881 - Hampshire vs Warwickshire
2016-07-03 - club - CCH - male - 947023 - Leicestershire vs Worcestershire
2016-07-03 - club - CCH - male - 947021 - Kent vs Essex
2016-07-03 - club - CCH - male - 946879 - Yorkshire vs Middlesex
2016-07-03 - club - CCH - male - 946877 - Lancashire vs Nottinghamshire
2016-07-03 - club - CCH - male - 946875 - Hampshire vs Durham
2016-07-02 - club - CCH - male - 947019 - Glamorgan vs Sussex
2016-07-02 - club - CCH - male - 946873 - Surrey vs Warwickshire
2016-06-27 - club - CCH - male - 947017 - Leicestershire vs Gloucestershire
2016-06-26 - club - CCH - male - 947015 - Kent vs Derbyshire
2016-06-26 - club - CCH - male - 946871 - Hampshire vs Somerset
2016-06-26 - club - CCH - male - 946869 - Nottinghamshire vs Warwickshire
2016-06-26 - club - CCH - male - 946867 - Lancashire vs Middlesex
2016-06-22 - club - CCH - male - 947013 - Sussex vs Northamptonshire
2016-06-20 - club - CCH - male - 947011 - Derbyshire vs Worcestershire
2016-06-20 - club - CCH - male - 946865 - Durham vs Yorkshire
2016-06-20 - club - CCH - male - 946863 - Lancashire vs Warwickshire
2016-06-19 - club - CCH - male - 947009 - Essex vs Leicestershire
2016-06-19 - club - CCH - male - 947007 - Glamorgan vs Kent
2016-06-19 - club - CCH - male - 946861 - Surrey vs Nottinghamshire
2016-05-29 - club - CCH - male - 947005 - Leicestershire vs Kent
2016-05-29 - club - CCH - male - 947003 - Worcestershire vs Gloucestershire
2016-05-29 - club - CCH - male - 946859 - Yorkshire vs Lancashire
2016-05-29 - club - CCH - male - 946857 - Middlesex vs Hampshire
2016-05-28 - club - CCH - male - 947001 - Northamptonshire vs Essex
2016-05-28 - club - CCH - male - 946999 - Derbyshire vs Sussex
2016-05-28 - club - CCH - male - 946855 - Surrey vs Somerset
2016-05-28 - club - CCH - male - 946853 - Nottinghamshire vs Durham
2016-05-22 - club - CCH - male - 946997 - Leicestershire vs Worcestershire
2016-05-22 - club - CCH - male - 946995 - Northamptonshire vs Gloucestershire
2016-05-22 - club - CCH - male - 946993 - Derbyshire vs Kent
2016-05-22 - club - CCH - male - 946991 - Glamorgan vs Essex
2016-05-22 - club - CCH - male - 946851 - Surrey vs Lancashire
2016-05-22 - club - CCH - male - 946849 - Somerset vs Middlesex
2016-05-22 - club - CCH - male - 946847 - Hampshire vs Nottinghamshire
2016-05-22 - club - CCH - male - 946845 - Warwickshire vs Durham
2016-05-15 - club - CCH - male - 946989 - Worcestershire vs Sussex
2016-05-15 - club - CCH - male - 946987 - Kent vs Northamptonshire
2016-05-15 - club - CCH - male - 946983 - Essex vs Derbyshire
2016-05-15 - club - CCH - male - 946843 - Somerset vs Yorkshire
2016-05-15 - club - CCH - male - 946841 - Warwickshire vs Nottinghamshire
2016-05-15 - club - CCH - male - 946839 - Middlesex vs Surrey
2016-05-15 - club - CCH - male - 946837 - Durham vs Lancashire
2016-05-08 - club - CCH - male - 946981 - Worcestershire vs Glamorgan
2016-05-08 - club - CCH - male - 946979 - Derbyshire vs Sussex
2016-05-08 - club - CCH - male - 946977 - Leicestershire vs Northamptonshire
2016-05-08 - club - CCH - male - 946975 - Gloucestershire vs Kent
2016-05-08 - club - CCH - male - 946835 - Surrey vs Yorkshire
2016-05-08 - club - CCH - male - 946833 - Somerset vs Warwickshire
2016-05-08 - club - CCH - male - 946831 - Nottinghamshire vs Middlesex
2016-05-08 - club - CCH - male - 946829 - Hampshire vs Lancashire
2016-05-01 - club - CCH - male - 946973 - Sussex vs Leicestershire
2016-05-01 - club - CCH - male - 946971 - Glamorgan vs Kent
2016-05-01 - club - CCH - male - 946969 - Essex vs Worcestershire
2016-05-01 - club - CCH - male - 946967 - Derbyshire vs Northamptonshire
2016-05-01 - club - CCH - male - 946827 - Nottinghamshire vs Yorkshire
2016-05-01 - club - CCH - male - 946825 - Hampshire vs Middlesex
2016-05-01 - club - CCH - male - 946823 - Lancashire vs Somerset
2016-05-01 - club - CCH - male - 946821 - Surrey vs Durham
2016-04-24 - club - CCH - male - 946965 - Gloucestershire vs Worcestershire
2016-04-24 - club - CCH - male - 946963 - Essex vs Northamptonshire
2016-04-24 - club - CCH - male - 946961 - Kent vs Leicestershire
2016-04-24 - club - CCH - male - 946959 - Glamorgan vs Derbyshire
2016-04-24 - club - CCH - male - 946819 - Yorkshire vs Warwickshire
2016-04-24 - club - CCH - male - 946817 - Surrey vs Somerset
2016-04-24 - club - CCH - male - 946815 - Middlesex vs Durham
2016-04-17 - club - CCH - male - 946957 - Glamorgan vs Leicestershire
2016-04-17 - club - CCH - male - 946955 - Sussex vs Essex
2016-04-17 - club - CCH - male - 946953 - Derbyshire vs Gloucestershire
2016-04-17 - club - CCH - male - 946813 - Middlesex vs Warwickshire
2016-04-17 - club - CCH - male - 946811 - Nottinghamshire vs Lancashire
2016-04-17 - club - CCH - male - 946809 - Yorkshire vs Hampshire
2016-04-10 - club - CCH - male - 946947 - Gloucestershire vs Essex
2016-04-10 - club - CCH - male - 946807 - Hampshire vs Warwickshire
2016-04-10 - club - CCH - male - 946805 - Nottinghamshire vs Surrey
2016-04-10 - club - CCH - male - 946803 - Durham vs Somerset
2016-03-30 - club - PKS - male - 917575 - Auckland Aces vs Central Stags
2016-03-30 - club - PKS - male - 917573 - Otago Volts vs Northern Districts
2016-03-23 - club - PKS - male - 917569 - Central Stags vs Otago Volts
2016-03-23 - club - PKS - male - 917567 - Northern Districts vs Canterbury
2016-03-23 - club - PKS - male - 917565 - Auckland Aces vs Wellington Firebirds
2016-03-15 - club - PKS - male - 917563 - Auckland Aces vs Otago Volts
2016-03-15 - club - PKS - male - 917561 - Wellington Firebirds vs Canterbury
2016-03-15 - club - PKS - male - 917559 - Northern Districts vs Central Stags
2016-03-08 - club - PKS - male - 917557 - Auckland Aces vs Central Stags
2016-03-08 - club - PKS - male - 917555 - Otago Volts vs Canterbury
2016-03-08 - club - PKS - male - 917553 - Northern Districts vs Wellington Firebirds
2016-02-20 - club - PKS - male - 917551 - Central Stags vs Wellington Firebirds
2016-02-20 - club - PKS - male - 917549 - Northern Districts vs Canterbury
2016-02-20 - club - PKS - male - 917547 - Auckland Aces vs Otago Volts
2016-02-13 - club - PKS - male - 917545 - Canterbury vs Central Stags
2016-02-13 - club - PKS - male - 917543 - Otago Volts vs Northern Districts
2016-02-13 - club - PKS - male - 917541 - Wellington Firebirds vs Auckland Aces
2016-02-05 - club - PKS - male - 917539 - Wellington Firebirds vs Otago Volts
2016-02-05 - club - PKS - male - 917537 - Canterbury vs Auckland Aces
2016-02-05 - club - PKS - male - 917535 - Northern Districts vs Central Stags
2016-01-31 - international - MDM - male - 952193 - Papua New Guinea vs Ireland
2015-12-17 - club - PKS - male - 917533 - Canterbury vs Central Stags
2015-12-17 - club - PKS - male - 917531 - Northern Districts vs Auckland Aces
2015-12-17 - club - PKS - male - 917529 - Wellington Firebirds vs Otago Volts
2015-11-11 - international - MDM - male - 911047 - United Arab Emirates vs Hong Kong
2015-10-24 - international - MDM - male - 911041 - Namibia vs Ireland
2015-10-24 - club - PKS - male - 917527 - Canterbury vs Otago Volts
2015-10-23 - club - PKS - male - 917525 - Northern Districts vs Auckland Aces
2015-10-23 - club - PKS - male - 917523 - Central Stags vs Wellington Firebirds
2015-10-15 - club - PKS - male - 917521 - Wellington Firebirds vs Northern Districts
2015-10-15 - club - PKS - male - 917519 - Otago Volts vs Central Stags
2015-10-15 - club - PKS - male - 917517 - Canterbury vs Auckland Aces
2015-09-22 - club - CCH - male - 804445 - Surrey vs Northamptonshire
2015-09-22 - club - CCH - male - 804443 - Glamorgan vs Gloucestershire
2015-09-22 - club - CCH - male - 804441 - Essex vs Lancashire
2015-09-22 - club - CCH - male - 804439 - Leicestershire vs Derbyshire
2015-09-22 - club - CCH - male - 804301 - Yorkshire vs Sussex
2015-09-22 - club - CCH - male - 804299 - Middlesex vs Worcestershire
2015-09-22 - club - CCH - male - 804297 - Somerset vs Warwickshire
2015-09-22 - club - CCH - male - 804295 - Nottinghamshire vs Hampshire
2015-09-14 - club - CCH - male - 804437 - Glamorgan vs Northamptonshire
2015-09-14 - club - CCH - male - 804435 - Leicestershire vs Essex
2015-09-14 - club - CCH - male - 804433 - Surrey vs Lancashire
2015-09-14 - club - CCH - male - 804431 - Kent vs Gloucestershire
2015-09-14 - club - CCH - male - 804293 - Nottinghamshire vs Warwickshire
2015-09-14 - club - CCH - male - 804291 - Sussex vs Somerset
2015-09-14 - club - CCH - male - 804289 - Hampshire vs Yorkshire
2015-09-14 - club - CCH - male - 804287 - Worcestershire vs Durham
2015-09-09 - club - CCH - male - 804429 - Kent vs Glamorgan
2015-09-09 - club - CCH - male - 804427 - Essex vs Derbyshire
2015-09-09 - club - CCH - male - 804285 - Hampshire vs Somerset
2015-09-09 - club - CCH - male - 804283 - Nottinghamshire vs Durham
2015-09-09 - club - CCH - male - 804281 - Middlesex vs Yorkshire
2015-09-01 - club - CCH - male - 804425 - Derbyshire vs Surrey
2015-09-01 - club - CCH - male - 804423 - Leicestershire vs Gloucestershire
2015-09-01 - club - CCH - male - 804419 - Essex vs Northamptonshire
2015-09-01 - club - CCH - male - 804279 - Somerset vs Yorkshire
2015-09-01 - club - CCH - male - 804277 - Worcestershire vs Sussex
2015-09-01 - club - CCH - male - 804275 - Middlesex vs Warwickshire
2015-09-01 - club - CCH - male - 804273 - Durham vs Hampshire
2015-08-21 - club - CCH - male - 804417 - Northamptonshire vs Leicestershire
2015-08-21 - club - CCH - male - 804415 - Lancashire vs Glamorgan
2015-08-21 - club - CCH - male - 804413 - Gloucestershire vs Surrey
2015-08-21 - club - CCH - male - 804411 - Derbyshire vs Kent
2015-08-21 - club - CCH - male - 804271 - Yorkshire vs Sussex
2015-08-21 - club - CCH - male - 804269 - Somerset vs Worcestershire
2015-08-21 - club - CCH - male - 804267 - Nottinghamshire vs Warwickshire
2015-08-21 - club - CCH - male - 804265 - Middlesex vs Durham
2015-08-07 - club - CCH - male - 804409 - Derbyshire vs Leicestershire
2015-08-07 - club - CCH - male - 804263 - Yorkshire vs Durham
2015-08-07 - club - CCH - male - 804261 - Worcestershire vs Nottinghamshire
2015-08-07 - club - CCH - male - 804259 - Middlesex vs Sussex
2015-08-07 - club - CCH - male - 804257 - Hampshire vs Warwickshire
2015-08-06 - club - CCH - male - 804405 - Glamorgan vs Gloucestershire
2015-08-04 - club - CCH - male - 804403 - Kent vs Northamptonshire
2015-07-19 - club - CCH - male - 804401 - Essex vs Kent
2015-07-19 - club - CCH - male - 804255 - Yorkshire vs Worcestershire
2015-07-19 - club - CCH - male - 804253 - Nottinghamshire vs Sussex
2015-07-19 - club - CCH - male - 804251 - Durham vs Hampshire
2015-07-18 - club - CCH - male - 804397 - Derbyshire vs Northamptonshire
2015-07-18 - club - CCH - male - 804249 - Somerset vs Warwickshire
2015-07-15 - club - CCH - male - 804395 - Gloucestershire vs Leicestershire
2015-07-13 - club - CCH - male - 804393 - Kent vs Surrey
2015-07-12 - club - CCH - male - 804391 - Essex vs Glamorgan
2015-07-12 - club - CCH - male - 804247 - Durham vs Warwickshire
2015-07-11 - club - CCH - male - 804245 - Middlesex vs Somerset
2015-07-08 - club - CCH - male - 804389 - Northamptonshire vs Gloucestershire
2015-07-06 - club - CCH - male - 804387 - Lancashire vs Essex
2015-07-06 - club - CCH - male - 804385 - Glamorgan vs Derbyshire
2015-07-06 - club - CCH - male - 804243 - Worcestershire vs Hampshire
2015-07-05 - club - CCH - male - 804383 - Leicestershire vs Kent
2015-07-05 - club - CCH - male - 804241 - Yorkshire vs Warwickshire
2015-07-05 - club - CCH - male - 804239 - Sussex vs Somerset
2015-07-05 - club - CCH - male - 804237 - Middlesex vs Nottinghamshire
2015-06-29 - club - CCH - male - 804381 - Northamptonshire vs Lancashire
2015-06-29 - club - CCH - male - 804235 - Nottinghamshire vs Worcestershire
2015-06-28 - club - CCH - male - 804233 - Sussex vs Warwickshire
2015-06-28 - club - CCH - male - 804231 - Hampshire vs Middlesex
2015-06-28 - club - CCH - male - 804229 - Yorkshire vs Durham
2015-06-27 - club - CCH - male - 804379 - Surrey vs Gloucestershire
2015-06-22 - club - CCH - male - 804377 - Glamorgan vs Leicestershire
2015-06-22 - club - CCH - male - 804227 - Nottinghamshire vs Yorkshire
2015-06-21 - club - CCH - male - 804375 - Essex vs Gloucestershire
2015-06-21 - club - CCH - male - 804373 - Surrey vs Derbyshire
2015-06-21 - club - CCH - male - 804225 - Middlesex vs Worcestershire
2015-06-21 - club - CCH - male - 804223 - Somerset vs Hampshire
2015-06-20 - club - CCH - male - 804371 - Kent vs Northamptonshire
2015-06-15 - club - CCH - male - 804369 - Surrey vs Glamorgan
2015-06-15 - club - CCH - male - 804221 - Durham vs Sussex
2015-06-14 - club - CCH - male - 804367 - Leicestershire vs Lancashire
2015-06-14 - club - CCH - male - 804365 - Derbyshire vs Essex
2015-06-14 - club - CCH - male - 804219 - Worcestershire vs Warwickshire
2015-06-14 - club - CCH - male - 804217 - Nottinghamshire vs Somerset
2015-06-07 - club - CCH - male - 804363 - Essex vs Northamptonshire
2015-06-07 - club - CCH - male - 804361 - Surrey vs Leicestershire
2015-06-07 - club - CCH - male - 804359 - Kent vs Derbyshire
2015-06-07 - club - CCH - male - 804357 - Lancashire vs Gloucestershire
2015-06-07 - club - CCH - male - 804215 - Middlesex vs Yorkshire
2015-06-07 - club - CCH - male - 804213 - Sussex vs Hampshire
2015-06-07 - club - CCH - male - 804211 - Durham vs Somerset
2015-06-01 - club - CCH - male - 804209 - Nottinghamshire vs Sussex
2015-05-31 - club - CCH - male - 804355 - Surrey vs Lancashire
2015-05-31 - club - CCH - male - 804353 - Glamorgan vs Northamptonshire
2015-05-31 - club - CCH - male - 804351 - Essex vs Leicestershire
2015-05-31 - club - CCH - male - 804349 - Gloucestershire vs Derbyshire
2015-05-31 - club - CCH - male - 804207 - Warwickshire vs Middlesex
2015-05-31 - club - CCH - male - 804205 - Hampshire vs Worcestershire
2015-05-24 - club - CCH - male - 804201 - Warwickshire vs Sussex
2015-05-18 - club - CCH - male - 804343 - Northamptonshire vs Surrey
2015-05-18 - club - CCH - male - 804341 - Gloucestershire vs Kent
2015-05-18 - club - CCH - male - 804339 - Glamorgan vs Essex
2015-05-17 - club - CCH - male - 804337 - Lancashire vs Leicestershire
2015-05-17 - club - CCH - male - 804197 - Warwickshire vs Durham
2015-05-17 - club - CCH - male - 804195 - Somerset vs Nottinghamshire
2015-05-17 - club - CCH - male - 804193 - Hampshire vs Middlesex
2015-05-10 - club - CCH - male - 804333 - Gloucestershire vs Lancashire
2015-05-10 - club - CCH - male - 804331 - Kent vs Glamorgan
2015-05-10 - club - CCH - male - 804329 - Derbyshire vs Northamptonshire
2015-05-10 - club - CCH - male - 804191 - Yorkshire vs Hampshire
2015-05-10 - club - CCH - male - 804189 - Middlesex vs Sussex
2015-05-10 - club - CCH - male - 804187 - Nottinghamshire vs Durham
2015-05-09 - club - CCH - male - 804185 - Warwickshire vs Worcestershire
2015-05-03 - club - CCH - male - 804327 - Northamptonshire vs Lancashire
2015-05-03 - club - CCH - male - 804325 - Leicestershire vs Kent
2015-05-03 - club - CCH - male - 804323 - Derbyshire vs Glamorgan
2015-05-03 - club - CCH - male - 804321 - Essex vs Gloucestershire
2015-05-03 - club - CCH - male - 804183 - Somerset vs Worcestershire
2015-05-02 - club - CCH - male - 804181 - Middlesex vs Durham
2015-04-26 - club - CCH - male - 804319 - Surrey vs Essex
2015-04-26 - club - CCH - male - 804317 - Northamptonshire vs Leicestershire
2015-04-26 - club - CCH - male - 804315 - Lancashire vs Kent
2015-04-26 - club - CCH - male - 804313 - Gloucestershire vs Derbyshire
2015-04-26 - club - CCH - male - 804179 - Warwickshire vs Yorkshire
2015-04-26 - club - CCH - male - 804177 - Somerset vs Middlesex
2015-04-26 - club - CCH - male - 804175 - Nottinghamshire vs Hampshire
2015-04-26 - club - CCH - male - 804173 - Sussex vs Durham
2015-04-19 - club - CCH - male - 804311 - Surrey vs Glamorgan
2015-04-19 - club - CCH - male - 804309 - Kent vs Essex
2015-04-19 - club - CCH - male - 804307 - Lancashire vs Derbyshire
2015-04-19 - club - CCH - male - 804171 - Hampshire vs Warwickshire
2015-04-19 - club - CCH - male - 804169 - Sussex vs Worcestershire
2015-04-19 - club - CCH - male - 804167 - Nottinghamshire vs Yorkshire
2015-04-12 - club - CCH - male - 804305 - Northamptonshire vs Gloucestershire
2015-04-12 - club - CCH - male - 804303 - Glamorgan vs Leicestershire
2015-04-12 - club - CCH - male - 804163 - Somerset vs Durham
2015-04-12 - club - CCH - male - 804161 - Nottinghamshire vs Middlesex
2015-04-12 - club - CCH - male - 804159 - Sussex vs Hampshire
2015-04-01 - club - PKS - male - 770817 - Otago Volts vs Auckland Aces
2015-04-01 - club - PKS - male - 770815 - Northern Districts vs Canterbury
2015-04-01 - club - PKS - male - 770813 - Wellington Firebirds vs Central Stags
2015-03-25 - club - PKS - male - 770811 - Northern Districts vs Wellington Firebirds
2015-03-25 - club - PKS - male - 770807 - Canterbury vs Otago Volts
2015-03-24 - club - PKS - male - 770809 - Auckland Aces vs Central Stags
2015-03-18 - club - PKS - male - 770805 - Northern Districts vs Otago Volts
2015-03-17 - club - PKS - male - 770803 - Wellington Firebirds vs Auckland Aces
2015-03-17 - club - PKS - male - 770801 - Canterbury vs Central Stags
2015-03-09 - club - PKS - male - 770799 - Auckland Aces vs Otago Volts
2015-03-09 - club - PKS - male - 770797 - Canterbury vs Northern Districts
2015-03-08 - club - PKS - male - 770795 - Central Stags vs Wellington Firebirds
2015-03-01 - club - PKS - male - 770793 - Auckland Aces vs Canterbury
2015-02-28 - club - PKS - male - 770791 - Wellington Firebirds vs Otago Volts
2015-02-27 - club - PKS - male - 770789 - Northern Districts vs Central Stags
2015-02-16 - club - PKS - male - 770787 - Canterbury vs Auckland Aces
2015-02-16 - club - PKS - male - 770783 - Wellington Firebirds vs Otago Volts
2015-02-15 - club - PKS - male - 770785 - Northern Districts vs Central Stags
2015-02-06 - club - PKS - male - 770781 - Auckland Aces vs Northern Districts
2015-02-06 - club - PKS - male - 770779 - Wellington Firebirds vs Canterbury
2015-02-06 - club - PKS - male - 770777 - Central Stags vs Otago Volts
2014-12-18 - club - PKS - male - 770775 - Central Stags vs Auckland Aces
2014-12-18 - club - PKS - male - 770773 - Northern Districts vs Wellington Firebirds
2014-12-18 - club - PKS - male - 770771 - Otago Volts vs Canterbury
2014-12-11 - club - PKS - male - 770769 - Northern Districts vs Otago Volts
2014-12-11 - club - PKS - male - 770767 - Canterbury vs Central Stags
2014-12-11 - club - PKS - male - 770765 - Wellington Firebirds vs Auckland Aces
2014-10-26 - club - PKS - male - 770763 - Otago Volts vs Central Stags
2014-10-25 - club - PKS - male - 770761 - Canterbury vs Wellington Firebirds
2014-10-23 - club - PKS - male - 770759 - Northern Districts vs Auckland Aces
2014-09-23 - club - CCH - male - 693007 - Gloucestershire vs Kent
2014-09-23 - club - CCH - male - 693005 - Worcestershire vs Essex
2014-09-23 - club - CCH - male - 693003 - Derbyshire vs Leicestershire
2014-09-23 - club - CCH - male - 693001 - Hampshire vs Glamorgan
2014-09-23 - club - CCH - male - 692863 - Durham vs Warwickshire
2014-09-23 - club - CCH - male - 692861 - Middlesex vs Lancashire
2014-09-23 - club - CCH - male - 692859 - Yorkshire vs Somerset
2014-09-23 - club - CCH - male - 692857 - Sussex vs Northamptonshire
2014-09-15 - club - CCH - male - 692999 - Kent vs Hampshire
2014-09-15 - club - CCH - male - 692997 - Leicestershire vs Essex
2014-09-15 - club - CCH - male - 692995 - Surrey vs Derbyshire
2014-09-15 - club - CCH - male - 692855 - Durham vs Northamptonshire
2014-09-15 - club - CCH - male - 692853 - Somerset vs Middlesex
2014-09-15 - club - CCH - male - 692851 - Sussex vs Nottinghamshire
2014-09-09 - club - CCH - male - 692991 - Kent vs Essex
2014-09-09 - club - CCH - male - 692989 - Worcestershire vs Surrey
2014-09-09 - club - CCH - male - 692987 - Glamorgan vs Derbyshire
2014-09-09 - club - CCH - male - 692849 - Northamptonshire vs Warwickshire
2014-09-09 - club - CCH - male - 692847 - Lancashire vs Sussex
2014-09-09 - club - CCH - male - 692845 - Durham vs Middlesex
2014-09-09 - club - CCH - male - 692843 - Yorkshire vs Nottinghamshire
2014-08-31 - club - CCH - male - 692985 - Leicestershire vs Hampshire
2014-08-31 - club - CCH - male - 692983 - Glamorgan vs Kent
2014-08-31 - club - CCH - male - 692981 - Derbyshire vs Worcestershire
2014-08-31 - club - CCH - male - 692841 - Durham vs Nottinghamshire
2014-08-31 - club - CCH - male - 692837 - Warwickshire vs Middlesex
2014-08-15 - club - CCH - male - 692979 - Hampshire vs Kent
2014-08-15 - club - CCH - male - 692977 - Surrey vs Leicestershire
2014-08-15 - club - CCH - male - 692975 - Worcestershire vs Gloucestershire
2014-08-15 - club - CCH - male - 692831 - Northamptonshire vs Nottinghamshire
2014-08-15 - club - CCH - male - 692829 - Sussex vs Yorkshire
2014-08-15 - club - CCH - male - 692827 - Warwickshire vs Somerset
2014-07-21 - club - CCH - male - 692971 - Worcestershire vs Gloucestershire
2014-07-21 - club - CCH - male - 692825 - Sussex vs Warwickshire
2014-07-20 - club - CCH - male - 692969 - Glamorgan vs Derbyshire
2014-07-20 - club - CCH - male - 692967 - Kent vs Surrey
2014-07-19 - club - CCH - male - 692823 - Yorkshire vs Middlesex
2014-07-14 - club - CCH - male - 692965 - Gloucestershire vs Derbyshire
2014-07-13 - club - CCH - male - 692963 - Hampshire vs Essex
2014-07-13 - club - CCH - male - 692961 - Worcestershire vs Leicestershire
2014-07-13 - club - CCH - male - 692821 - Warwickshire vs Durham
2014-07-13 - club - CCH - male - 692819 - Lancashire vs Nottinghamshire
2014-07-12 - club - CCH - male - 692817 - Somerset vs Northamptonshire
2014-07-07 - club - CCH - male - 692959 - Derbyshire vs Essex
2014-07-07 - club - CCH - male - 692957 - Leicestershire vs Kent
2014-07-07 - club - CCH - male - 692955 - Hampshire vs Gloucestershire
2014-07-07 - club - CCH - male - 692815 - Yorkshire vs Durham
2014-07-06 - club - CCH - male - 692953 - Glamorgan vs Surrey
2014-07-06 - club - CCH - male - 692813 - Sussex vs Northamptonshire
2014-06-29 - club - CCH - male - 692951 - Gloucestershire vs Essex
2014-06-29 - club - CCH - male - 692949 - Worcestershire vs Glamorgan
2014-06-29 - club - CCH - male - 692809 - Nottinghamshire vs Warwickshire
2014-06-29 - club - CCH - male - 692807 - Middlesex vs Northamptonshire
2014-06-29 - club - CCH - male - 692805 - Lancashire vs Somerset
2014-06-28 - club - CCH - male - 692947 - Surrey vs Hampshire
2014-06-22 - club - CCH - male - 692945 - Kent vs Derbyshire
2014-06-22 - club - CCH - male - 692943 - Surrey vs Leicestershire
2014-06-22 - club - CCH - male - 692803 - Warwickshire vs Yorkshire
2014-06-22 - club - CCH - male - 692801 - Durham vs Sussex
2014-06-22 - club - CCH - male - 692799 - Lancashire vs Northamptonshire
2014-06-22 - club - CCH - male - 692797 - Somerset vs Nottinghamshire
2014-06-21 - club - CCH - male - 692941 - Gloucestershire vs Glamorgan
2014-06-16 - club - CCH - male - 692795 - Sussex vs Yorkshire
2014-06-15 - club - CCH - male - 692939 - Hampshire vs Essex
2014-06-15 - club - CCH - male - 692937 - Derbyshire vs Surrey
2014-06-15 - club - CCH - male - 692935 - Worcestershire vs Leicestershire
2014-06-15 - club - CCH - male - 692933 - Kent vs Glamorgan
2014-06-15 - club - CCH - male - 692793 - Durham vs Lancashire
2014-06-15 - club - CCH - male - 692791 - Northamptonshire vs Warwickshire
2014-06-14 - club - CCH - male - 692789 - Middlesex vs Nottinghamshire
2014-06-09 - club - CCH - male - 692931 - Gloucestershire vs Surrey
2014-06-08 - club - CCH - male - 692929 - Worcestershire vs Hampshire
2014-06-08 - club - CCH - male - 692867 - Leicestershire vs Derbyshire
2014-06-08 - club - CCH - male - 692787 - Lancashire vs Warwickshire
2014-06-08 - club - CCH - male - 692785 - Nottinghamshire vs Yorkshire
2014-06-08 - club - CCH - male - 692783 - Sussex vs Somerset
2014-06-07 - club - CCH - male - 692927 - Kent vs Essex
2014-06-02 - club - CCH - male - 692925 - Leicestershire vs Gloucestershire
2014-06-01 - club - CCH - male - 692923 - Hampshire vs Derbyshire
2014-06-01 - club - CCH - male - 692921 - Glamorgan vs Essex
2014-06-01 - club - CCH - male - 692919 - Worcestershire vs Surrey
2014-06-01 - club - CCH - male - 692781 - Durham vs Middlesex
2014-06-01 - club - CCH - male - 692779 - Somerset vs Lancashire
2014-05-31 - club - CCH - male - 692775 - Yorkshire vs Northamptonshire
2014-05-25 - club - CCH - male - 692917 - Essex vs Surrey
2014-05-25 - club - CCH - male - 692915 - Derbyshire vs Gloucestershire
2014-05-25 - club - CCH - male - 692913 - Leicestershire vs Glamorgan
2014-05-25 - club - CCH - male - 692911 - Kent vs Worcestershire
2014-05-25 - club - CCH - male - 692771 - Somerset vs Warwickshire
2014-05-25 - club - CCH - male - 692769 - Lancashire vs Yorkshire
2014-05-25 - club - CCH - male - 692767 - Nottinghamshire vs Durham
2014-05-19 - club - CCH - male - 692765 - Durham vs Somerset
2014-05-18 - club - CCH - male - 692909 - Gloucestershire vs Kent
2014-05-18 - club - CCH - male - 692907 - Hampshire vs Leicestershire
2014-05-18 - club - CCH - male - 692905 - Worcestershire vs Essex
2014-05-18 - club - CCH - male - 692763 - Northamptonshire vs Middlesex
2014-05-11 - club - CCH - male - 692903 - Glamorgan vs Hampshire
2014-05-11 - club - CCH - male - 692901 - Derbyshire vs Kent
2014-05-11 - club - CCH - male - 692899 - Gloucestershire vs Surrey
2014-05-11 - club - CCH - male - 692761 - Yorkshire vs Warwickshire
2014-05-11 - club - CCH - male - 692759 - Sussex vs Durham
2014-05-11 - club - CCH - male - 692755 - Northamptonshire vs Nottinghamshire
2014-05-04 - club - CCH - male - 692893 - Worcestershire vs Glamorgan
2014-05-04 - club - CCH - male - 692753 - Middlesex vs Warwickshire
2014-05-04 - club - CCH - male - 692749 - Sussex vs Lancashire
2014-05-04 - club - CCH - male - 692747 - Nottinghamshire vs Somerset
2014-04-27 - club - CCH - male - 692891 - Hampshire vs Surrey
2014-04-27 - club - CCH - male - 692889 - Gloucestershire vs Essex
2014-04-27 - club - CCH - male - 692887 - Leicestershire vs Glamorgan
2014-04-27 - club - CCH - male - 692885 - Derbyshire vs Worcestershire
2014-04-27 - club - CCH - male - 692745 - Somerset vs Sussex
2014-04-27 - club - CCH - male - 692741 - Lancashire vs Northamptonshire
2014-04-27 - club - CCH - male - 692739 - Warwickshire vs Nottinghamshire
2014-04-20 - club - CCH - male - 692883 - Leicestershire vs Kent
2014-04-20 - club - CCH - male - 692881 - Hampshire vs Derbyshire
2014-04-20 - club - CCH - male - 692877 - Glamorgan vs Gloucestershire
2014-04-20 - club - CCH - male - 692737 - Durham vs Somerset
2014-04-20 - club - CCH - male - 692735 - Lancashire vs Warwickshire
2014-04-20 - club - CCH - male - 692733 - Yorkshire vs Northamptonshire
2014-04-13 - club - CCH - male - 692875 - Gloucestershire vs Hampshire
2014-04-13 - club - CCH - male - 692873 - Essex vs Derbyshire
2014-04-13 - club - CCH - male - 692871 - Worcestershire vs Kent
2014-04-13 - club - CCH - male - 692731 - Warwickshire vs Sussex
2014-04-13 - club - CCH - male - 692727 - Durham vs Northamptonshire
2014-04-13 - club - CCH - male - 692725 - Yorkshire vs Somerset
2014-04-06 - club - CCH - male - 692869 - Hampshire vs Worcestershire
2014-04-06 - club - CCH - male - 692723 - Middlesex vs Sussex
2014-02-23 - club - PKS - male - 665583 - Central Stags vs Canterbury
2014-02-23 - club - PKS - male - 665581 - Otago Volts vs Northern Districts
2014-02-23 - club - PKS - male - 665579 - Auckland Aces vs Wellington Firebirds
2014-02-16 - club - PKS - male - 665577 - Otago Volts vs Auckland Aces
2014-02-16 - club - PKS - male - 665575 - Canterbury vs Central Stags
2014-02-16 - club - PKS - male - 665573 - Northern Districts vs Wellington Firebirds
2014-02-07 - club - PKS - male - 665571 - Central Stags vs Otago Volts
2014-02-07 - club - PKS - male - 665569 - Northern Districts vs Wellington Firebirds
2014-02-07 - club - PKS - male - 665567 - Canterbury vs Auckland Aces
2014-01-30 - club - PKS - male - 665563 - Northern Districts vs Canterbury
2014-01-30 - club - PKS - male - 665561 - Auckland Aces vs Otago Volts
2014-01-23 - club - PKS - male - 665559 - Canterbury vs Otago Volts
2014-01-23 - club - PKS - male - 665557 - Northern Districts vs Central Stags
2014-01-23 - club - PKS - male - 665555 - Wellington Firebirds vs Auckland Aces
2013-12-20 - club - PKS - male - 665553 - Central Stags vs Otago Volts
2013-12-20 - club - PKS - male - 665549 - Northern Districts vs Auckland Aces
2013-12-12 - club - PKS - male - 665543 - Central Stags vs Auckland Aces
2013-12-04 - club - PKS - male - 665541 - Canterbury vs Wellington Firebirds
2013-12-04 - club - PKS - male - 665539 - Otago Volts vs Northern Districts
2013-12-04 - club - PKS - male - 665537 - Central Stags vs Auckland Aces
2013-11-26 - club - PKS - male - 665535 - Northern Districts vs Central Stags
2013-11-19 - club - PKS - male - 665533 - Canterbury vs Otago Volts
2013-11-12 - club - PKS - male - 665531 - Auckland Aces vs Canterbury
2013-11-07 - club - PKS - male - 665529 - Central Stags vs Wellington Firebirds
2013-10-31 - club - PKS - male - 665527 - Northern Districts vs Auckland Aces
2013-10-27 - club - PKS - male - 665525 - Otago Volts vs Wellington Firebirds
2013-09-11 - international - MDM - male - 516863 - Scotland vs Ireland
2013-02-20 - club - PKS - male - 580753 - Wellington Firebirds vs Otago Volts
2013-02-20 - club - PKS - male - 580752 - Northern Districts vs Central Stags
2013-02-20 - club - PKS - male - 580751 - Auckland Aces vs Canterbury
2013-02-14 - club - PKS - male - 580750 - Auckland Aces vs Otago Volts
2013-02-14 - club - PKS - male - 580748 - Canterbury vs Central Stags
2013-01-31 - club - PKS - male - 580744 - Northern Districts vs Otago Volts
2013-01-24 - club - PKS - male - 580742 - Wellington Firebirds vs Otago Volts
2013-01-24 - club - PKS - male - 580741 - Auckland Aces vs Northern Districts
2012-12-17 - club - PKS - male - 580738 - Otago Volts vs Central Stags
2012-12-16 - club - PKS - male - 580737 - Canterbury vs Auckland Aces
2012-12-10 - club - PKS - male - 580736 - Central Stags vs Wellington Firebirds
2012-12-02 - club - PKS - male - 580734 - Auckland Aces vs Otago Volts
2012-11-26 - club - PKS - male - 580733 - Wellington Firebirds vs Auckland Aces
2012-11-26 - club - PKS - male - 580732 - Central Stags vs Otago Volts
2012-11-19 - club - PKS - male - 580731 - Wellington Firebirds vs Canterbury
2012-11-17 - club - PKS - male - 580730 - Northern Districts vs Central Stags
2012-11-12 - club - PKS - male - 580729 - Canterbury vs Otago Volts
2012-11-10 - club - PKS - male - 580728 - Northern Districts vs Auckland Aces
2012-11-04 - club - PKS - male - 580727 - Northern Districts vs Otago Volts
2012-11-04 - club - PKS - male - 580726 - Central Stags vs Auckland Aces
2012-10-27 - club - PKS - male - 580724 - Canterbury vs Otago Volts
2012-09-29 - international - MDM - male - 516852 - Kenya vs Namibia
2011-07-28 - international - MDM - male - 516841 - United Arab Emirates vs Kenya
2010-02-20 - international - MDM - male - 438938 - Netherlands vs Kenya
2009-08-14 - international - MDM - male - 415161 - Kenya vs Canada
2007-11-01 - international - MDM - male - 292302 - Bermuda vs Kenya
2007-10-12 - international - MDM - male - 292300 - Canada vs Kenya
2006-12-05 - international - MDM - male - 247219 - Canada vs Netherlands
